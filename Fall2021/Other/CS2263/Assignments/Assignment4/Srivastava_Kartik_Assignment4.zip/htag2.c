#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "htag3.h"

#define TOTALTAGS 100

int main(int argc, char** argv)
{
    printf("Count: \n");
}