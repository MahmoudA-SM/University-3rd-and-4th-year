#include "isFib.h"
#include <stdio.h>

int main()
{
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    isFib(number);
    return 0;
}