#include "Strings.h"
#include <stdio.h>
#include <stdlib.h>
int main()
{
    String works = "It works!";
    printf("%s\n", works);
    return EXIT_SUCCESS;
}