//binaryTree.h
#include <stdio.h>
#include <stdlib.h>

typedef struct anode{
	char payload;
	struct anode* left;
	struct anode* right;
}Node, *pNode;

Node* mallocNode();

Node* createNode(char payload);

Node* addNode(char payload, Node* pHead);

void freeNode(Node* node);

void printfBTN(char c);

void printInOrder(Node* node);