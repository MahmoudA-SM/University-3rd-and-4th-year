//binaryTree.c
#include <stdlib.h>
#include <stdio.h>
#include "binaryTree.h"

Node* mallocNode(){
	Node* pNode = (Node*)malloc(sizeof(Node));
	if(pNode == (Node*)NULL){
		printf("Allocating memory failed.\n");
		return (Node*)NULL;
	}
	return pNode;
}

Node* createNode(char payload){
	Node* pFirst = mallocNode();
	pFirst->payload = payload;
	return pFirst;
}

Node* addNode(char payload, Node* pHead){
	Node* temp;
	temp = pHead;
	
	if(temp->left == (Node*)NULL){
		if(payload < temp->payload){
			temp->left = mallocNode();
			temp->left->payload = payload;
			return temp->left;
		}
	}
	
	if(temp->right == (Node*)NULL){
		if(payload > temp->payload){
			temp->right = mallocNode();
			temp->right->payload = payload;
			return temp->right;
		}
	}
}

void freeNode(Node* node){
    free(node);
}

void printfBTN(char c){
	printf("%c\n", c);
}

void printInOrder(Node* node){
	if(node == (Node*)NULL){
		return;
	}
	
	printInOrder(node->left);
	printfBTN(node->payload);
	printInOrder(node->right);
}