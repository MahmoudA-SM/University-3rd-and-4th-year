//main.c
#include <stdio.h>
#include <stdlib.h>
#include "binaryTree.h"

int main(int argc, char* argv[]){
	char a = 'x';
	char b = 'y';
	char c = 'z';
	
	Node* root = createNode(b);
	Node* left = addNode(a, root);
	Node* right = addNode(c, root);
	
    printf("Binary Tree in order:\n");
	printInOrder(root);
	
	freeNode(root);
	freeNode(left);
	freeNode(right);
	
	return EXIT_SUCCESS;
}