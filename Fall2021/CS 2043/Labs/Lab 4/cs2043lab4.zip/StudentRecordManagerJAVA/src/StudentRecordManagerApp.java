
public class StudentRecordManagerApp {
	public static void main(String[] args) {
		SystemView systemView = new SystemView();
		SystemModel systemModel = new SystemModel(systemView);
		SystemController systemController = new SystemController();
		systemController.handleInput();
	}
}
