
/**
 * 
 */

import java.util.Set;
import java.util.Hashtable;

/** 
* <!-- begin-UML-doc -->
* <!-- end-UML-doc -->
* @author mmoustaf
* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
*/
public class SystemModel {
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	private Hashtable<String, StudentRecord> records;
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	private SystemView view;
	
	public SystemModel(SystemView view) {
		records = new Hashtable<String, StudentRecord>();
	}

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @param record
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void addRecord(StudentRecord record) {
		// begin-user-code
		// TODO Auto-generated method stub
		records.put(record.getName(), record);
		// end-user-code
	}

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @return
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public StudentRecord getRecord(String name) {
		// begin-user-code
		// TODO Auto-generated method stub
		view = new SystemView();
		view.displayRecord(records.get(name));
		return records.get(name);
		// end-user-code
	}
}