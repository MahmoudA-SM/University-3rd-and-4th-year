import java.util.Scanner;

/**
 * 
 */

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author mmoustaf
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SystemController {
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	private SystemModel model;
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	private SystemView view;
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void handleInput() {
		// begin-user-code
		// TODO Auto-generated method stub
		view = new SystemView();
		model = new SystemModel(view);
		StudentRecord sr;
		Scanner scan = new Scanner(System.in);
		while(true)
		{
//			System.out.println("Enter a number: \n1- Add a new record\n2- View a record\n3- Quit" );
			view.displayMessage("Enter a number: \n1- Add a new record\n2- View a record\n3- Quit");
			int input = scan.nextInt();
			if(input == 3) {
				break;
			}
			else if(input == 2) {
				view.displayMessage("Please enter the name");
				scan.nextLine();
				String name = scan.nextLine();
				model.getRecord(name);
			}
			else if(input == 1) {
				view.displayMessage("Please enter the name");
				scan.nextLine();
				String name = scan.nextLine();
				view.displayMessage("Please enter the grade");
				float grade = scan.nextFloat();
				sr = new StudentRecord(name, grade);
				model.addRecord(sr);
			}
			else {
				view.displayMessage("Please enter a number from the choices available");
			}
		}
		// end-user-code
	}
}