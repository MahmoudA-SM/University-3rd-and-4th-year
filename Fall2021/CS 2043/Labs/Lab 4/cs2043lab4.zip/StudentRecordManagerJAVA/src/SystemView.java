
/**
 * 
 */

/** 
* <!-- begin-UML-doc -->
* <!-- end-UML-doc -->
* @author mmoustaf
* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
*/
public class SystemView {
	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @param record
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void displayRecord(StudentRecord record) {
		// begin-user-code
		// TODO Auto-generated method stub
		record = new StudentRecord(record.getName(), record.getGrade());
		System.out.println(record.getName());
		System.out.println(record.getGrade());
		// end-user-code
	}

	/** 
	* <!-- begin-UML-doc -->
	* <!-- end-UML-doc -->
	* @param message
	* @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	*/
	public void displayMessage(String message) {
		// begin-user-code
		// TODO Auto-generated method stub
		System.out.println(message);
		// end-user-code
	}
}