import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ViewCourseListControlTest {

	private DataManager dm;
	private ViewCourseListControl control;
	
	@BeforeEach
	void setUp() throws Exception {
		dm = new DataManager();
		control = new ViewCourseListControl(dm);
	}

	@Test
	void testHandleViewCourseListCase1() { 
		
		//Exists
		
		dm.createCourseInfo("CS2043", "Software Engineering");
		int errorCode = control.handleViewCourseList("CS2043");
		assertEquals(0, errorCode);
	}
	
	@Test
	void testHandleViewCourseListCase2() {
		
		//Does not exist
		
		dm.createCourseInfo("CS2043", "Software Engineering");
		int errorCode = control.handleViewCourseList("CS2043A");
		assertEquals(1, errorCode);
	}
	
	
	//__________________________________________________________________

	@Test
	void testGetCourseList() {
		dm.createCourseInfo("CS2043", "Software Engineering");
		dm.createCourseRegistration("1234", "CS2043");
		dm.createCourseRegistration("6987", "CS2043");
		dm.createCourseRegistration("2323", "CS2043");
		dm.createCourseRegistration("2424", "CS2043");
		
		ArrayList<String> expectedStudentIDs = new ArrayList<String>();
		expectedStudentIDs.add("1234");
		expectedStudentIDs.add("6987");
		expectedStudentIDs.add("2323");
		expectedStudentIDs.add("2424");
		
		control.handleViewCourseList("CS2043");
		
		
		ArrayList<String> cl = control.getCourseList();
		
		assertArrayEquals(expectedStudentIDs.toArray(), cl.toArray());
		

	}

}
