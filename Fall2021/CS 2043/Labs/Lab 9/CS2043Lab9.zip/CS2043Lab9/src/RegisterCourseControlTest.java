import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RegisterCourseControlTest {

	private DataManager dm;
	private RegisterCourseControl control;
	
	
	@BeforeEach
	void setUp() throws Exception {
		dm = new DataManager();
		control = new RegisterCourseControl(dm);
	}

	@Test
	void testHandleRegisterCourseCase1() {
		
		//Does not exist
		
		dm.createCourseInfo("CS2043", "Software Engineering");
		dm.createCourseRegistration("2645", "CS2043");
		int errorCode = control.handleRegisterCourse("2645", "CS2222");
		assertEquals(1, errorCode);
	}

	
	@Test
	void testHandleRegisterCourseCase2() {
		
		//Duplicate
		
		dm.createCourseInfo("CS2043", "Software Engineering");
		dm.createCourseRegistration("2645", "CS2043");
		int errorCode = control.handleRegisterCourse("2645", "CS2043");
		assertEquals(2, errorCode);
	}
	
	
	@Test
	void testHandleRegisterCourseCase3() {


		//No Error
		
		dm.createCourseInfo("CS2043", "Software Engineering");
		int errorCode = control.handleRegisterCourse("2645", "CS2043");
		assertEquals(0, errorCode);

	}
}
