import java.util.Scanner;

public class AverageUI {
    private AverageCalculator averageCalculator = new AverageCalculator();
    public void handleIO() {
        Scanner scan = new Scanner(System.in);
        System.out.println("How many numbers do you want to input?");
        int numInputs = scan.nextInt();
        int [] inputArr = new int[numInputs];
        for (int i = 0; i < numInputs; i++) {
            inputArr[i] = scan.nextInt();
        }
        System.out.println(averageCalculator.computeAverage(inputArr));
    }
}
