
public class AverageApp {
    public static void main(String[] args) {
        AverageUI averageUI = new AverageUI();
        averageUI.handleIO();
    }
}