import java.util.*;
public class LoginUI {
	private LoginControl loginControl;
	
	public LoginUI(LoginControl loginControl) {
		this.loginControl = loginControl;
	}
	public void displayLoginForm() {
		System.out.println("Enter ID and password");
	}
	public void enterUserIDPassword() {
		Scanner scan = new Scanner(System.in);
		String idInput = scan.nextLine();
		String passInput = scan.nextLine(); 
		scan.close();
		if (loginControl.processLogin(idInput, passInput)) {
			displayConfirmation();
		}
		else {
			displayLoginErrorMessage();
		}
	}
	public void displayLoginErrorMessage() {
		System.out.println("Wrong ID or password");
	}
	public void displayConfirmation() {
		System.out.println("Logged in Succesfully");
	}
}
