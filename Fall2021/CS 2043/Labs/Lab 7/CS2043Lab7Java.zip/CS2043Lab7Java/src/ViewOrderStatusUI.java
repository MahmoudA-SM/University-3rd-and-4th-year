import java.util.ArrayList;

public class ViewOrderStatusUI {
	public ViewOrderStatusUI(ViewOrderStatusControl control) {
	}
	
	public void displayBookOrders(ArrayList <BookOrderObject>  bookOrders) {
//		System.out.println(bookOrders.size());
		for(int i = 0; i < bookOrders.size(); i++) {
			String Id = bookOrders.get(i).OrderID;
			String Status = bookOrders.get(i).Status;
			System.out.println(Id);
			System.out.println(Status);
		}
	}
	
	public String displayRequestLoginMessage() {
		return "Please log in first to see your orders";
		
	}
}
