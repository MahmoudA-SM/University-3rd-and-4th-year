
public class BookInfoObject {
	public String id;
	public String title;
	public String description;
	public String author; 
	public String isbn;
	public String publisher;
	int year; 
	int inventory;
}