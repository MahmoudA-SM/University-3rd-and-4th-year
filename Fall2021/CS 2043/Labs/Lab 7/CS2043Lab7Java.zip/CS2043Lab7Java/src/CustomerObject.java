
public class CustomerObject {
	public String customerID;
	public String name;
}
