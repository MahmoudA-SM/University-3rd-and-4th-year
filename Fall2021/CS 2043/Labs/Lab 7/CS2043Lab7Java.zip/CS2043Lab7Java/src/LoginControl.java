
public class LoginControl {
	private DataManager dataManager;
	private CustomerObject customer;
	public LoginControl(DataManager dm) {
		this.dataManager = dm;
	}
	public boolean processLogin(String userId, String password) {
		customer = dataManager.getUserAccount(userId,password);
		if(userId.equals(customer.customerID)) {
			return true;
		}
		return false;
		
	}
	public void saveCustomerObject() {
		//TODO
	}
	public CustomerObject getCustomerObject() {
		return customer;
	}
}
