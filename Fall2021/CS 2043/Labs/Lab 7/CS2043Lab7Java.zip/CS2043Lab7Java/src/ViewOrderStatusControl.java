import java.util.ArrayList;

public class ViewOrderStatusControl {
	private LoginControl lControl;
	private DataManager datamanager;
	
	public ViewOrderStatusControl(LoginControl lControl, DataManager datamanager) {
		this.lControl = lControl;
		this.datamanager = datamanager;
	}
	public ArrayList<BookOrderObject> handleOrderView() {
		String Id = lControl.getCustomerObject().customerID;
		return datamanager.getBookOrderByCustomer(Id);
	}
}
