
public class BookOrderObject {
	public String OrderID;
	public String Status;

}
