import java.util.ArrayList;

public class ViewOrderStatusMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataManager datamanager = new DataManager();
		LoginControl loginControl = new LoginControl(datamanager);
		LoginUI loginUI = new LoginUI(loginControl);
		ViewOrderStatusControl vControl = new ViewOrderStatusControl(loginControl, datamanager);
		ViewOrderStatusUI vUI = new ViewOrderStatusUI(vControl);
		System.out.println(vUI.displayRequestLoginMessage());
		loginUI.displayLoginForm();
		loginUI.enterUserIDPassword();
		ArrayList <BookOrderObject>  boO = vControl.handleOrderView();
		vUI.displayBookOrders(boO);
	}

}
