/*
example include file
*/
#define SUCCESS 0
#define MYNUM 63
int myPrintHelloMake(void);