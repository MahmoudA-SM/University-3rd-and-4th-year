#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "shell.h"
#include "fat32.h"
#include <stdbool.h>

#define BUF_SIZE 256
#define CMD_INFO "INFO"
#define CMD_DIR "DIR"
#define CMD_CD "CD"
#define CMD_GET "GET"
#define CMD_PUT "PUT"

ULONG bps;
ULONG spc;
ULONG dps;
ULONG reservedSec;
ULONG dataSecStart;
ULONG FATSz32;
ULONG bitMask = 0011111111;
char buffer[BUF_SIZE];
char bufferRaw[BUF_SIZE];
unsigned long *FAT;

void shellLoop(int fd)
{
	int running = true;
	uint32_t curDirClus;

	// TODO:
	fat32Head *h = createHead(fd);

	if (h == NULL)
	{
		running = false;
	}
	else
	{

		curDirClus = h->bs->BPB_RootClus;
	}
	while (running)
	{
		printf(">");
		scanf("%s", bufferRaw);
		if (strlen(bufferRaw) == 0)
		{
			running = false;
			continue;
		}

		bufferRaw[strlen(bufferRaw)] = '\0'; /* cut new line */
		for (int i = 0; i < strlen(bufferRaw) + 1; i++)
		{
			buffer[i] = toupper(bufferRaw[i]);
		}

		buffer[strlen(buffer)] = '\0'; /* cut new line */
		if (strncmp(buffer, CMD_INFO, strlen(CMD_INFO)) == 0)

			printInfo(h);

		// else if (strncmp(buffer, CMD_DIR, strlen(CMD_DIR)) == 0)
		// 	// doDir(h, curDirClus);

		// else if (strncmp(buffer, CMD_CD, strlen(CMD_CD)) == 0)
		// 	// curDirClus = doCD(h, curDirClus, buffer);

		// else if (strncmp(buffer, CMD_GET, strlen(CMD_GET)) == 0)
		// 	// doDownload(h, curDirClus, buffer);

		// else if (strncmp(buffer, CMD_PUT, strlen(CMD_PUT)) == 0)
		// 	// doUpload(h, curDirClus, buffer, bufferRaw);
		// 	printf("Bonus marks!\n");
		// else
		// 	printf("\nCommand not found\n");
	}
	printf("\nExited...\n");

	cleanupHead(h);
}

void cleanupHead(fat32Head *h)
{
	free(h);
}

void printInfo(fat32Head *fat32)
{
	int numSectors;
	int rootDir_SecNum;
	FAT = (unsigned long *)malloc(sizeof(unsigned long) * fat32->bs->BPB_FATSz32 * bps / 4);
	bps = fat32->bs->BPB_BytesPerSec;
	spc = fat32->bs->BPB_SecPerClus;
	numSectors = bps * fat32->bs->BPB_FATSz32 / 4;
	FATSz32 = fat32->bs->BPB_FATSz32;
	dps = bps / 32;
	reservedSec = fat32->bs->BPB_RsvdSecCnt;
	rootDir_SecNum = returnFirstSector(fat32->bs->BPB_RootClus);
	ULONG freeSpace = fat32->fsi->FSI_Free_Count * spc * bps;

	printf("---- Device Info ----\n");
	printf("OEM Name: %s\n", fat32->bs->BS_OEMName);
	printf("Label: %.11s\n", fat32->bs->BS_VolLab);
	printf("Type: %.8s\n", fat32->bs->BS_FilSysType);
	printf("Media Type: %x\n", fat32->bs->BPB_Media);
	printf("Size: %d\n", fat32->bs->BPB_BytesPerSec*fat32->bs->BPB_SecPerClus);
	printf("Drive Number: %d\n", fat32->bs->BS_DrvNum);
	printf("\n");

	printf("--- Geometry ---\n");
	printf("Bytes per Sector: %ld\n", bps);
	
	printf("Sectors Per Cluster: %d\n", fat32->bs->BPB_SecPerClus);
	printf("Total Sectors: %d\n", numSectors);
	printf("Sectors Per Track: %d\n", fat32->bs->BPB_SecPerTrk);
	printf("Heads: %d\n", fat32->bs->BPB_NumHeads);
	printf("Hidden Sectors: %d\n", fat32->bs->BPB_HiddSec);
	printf("\n");

	printf("--- FS Info ---\n");
	printf("Vol ID: %d\n", fat32->bs->BS_VolID);
	printf("Reserved Sectors %d\n",fat32->bs->BPB_RsvdSecCnt);
	printf("Number of FATs = %d\n", fat32->bs->BPB_NumFATs);
	printf("Fat Size: %d\n",fat32->bs->BPB_FATSz32);
	printf("Backup Boot Sector: %d\n", fat32->bs->BPB_BkBootSec);
	printf("\n");

	printf("Free Space: %ld\n", freeSpace);
	
	printf("Sector per Cluster: %ld\n", spc);
	
	printf("Usable Storage: %d\n", (bps / 4) * bps * spc);
	printf("Number of Clusters (Sectors): %d\n", numSectors);
	printf("Number of Clusters (Kbs): %d\n", numSectors * bps * spc / 1000);
	printf("asdasd: %d\n", fat32->fsi->FSI_Reserved2);
}
