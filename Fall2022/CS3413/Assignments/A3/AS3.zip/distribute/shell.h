#ifndef SHELL_H
#define SHELL_H

void shellLoop(int fd);

#endif
