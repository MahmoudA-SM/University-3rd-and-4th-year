#include "fat32.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <math.h>
#include <stdlib.h>

#define ULONG unsigned long 
#define BUFFER_SIZE 32


int fileID;
ULONG bps;
ULONG spc;
ULONG dps;
ULONG reservedSec;
ULONG dataSecStart; 
ULONG FATSz32;
unsigned char *buffer;
unsigned long *FAT;
fat32BS bootSector; 
FSI fsiStruct;

fat32Head *createHead(int fd)
{
    
    fat32Head* fat32;
    int count;
    int numSectors;
    char *input;
    buffer = malloc(BUFFER_SIZE);
    // fileID = open(fd, O_RDWR);

    // Read first 512 bytes -> boot sector
    count = read(fd, buffer, 512);
    memcpy(&bootSector, buffer, sizeof(fat32BS));
    // Get the boot sector information

    // Read fsi
    readSector(bootSector.BPB_FSInfo, buffer, 1);
    memcpy(&fsiStruct, buffer, sizeof(FSI));
    fat32 = malloc(sizeof(bootSector)+sizeof(fsiStruct));
    fat32->bs = &bootSector;
    fat32->fsi = &fsiStruct;
    
    return fat32;
    
}

int readSector(int sectorNum, unsigned char *buffer, int numSectors) 
{
	int dest, len;     /* used for error checking only */

    // Starting position in sector
	dest = lseek(fileID, sectorNum*bps, SEEK_SET);
	len = read(fileID, buffer, bps*numSectors);

	return len;
}



int readEntry(ULONG sectorNum, unsigned char *buffer, ULONG numSectors, ULONG entryNum) 
{
	int dest, len;     /* used for error checking only */

    // Starting position in entry
	dest = lseek(fileID, sectorNum*bps+(entryNum*32), SEEK_SET);
    lseek(fileID, sectorNum*bps+(entryNum*32), SEEK_SET);

    // Read the entry
	len = read(fileID, buffer, 32);
    //printf("Len: %d\n", len);

	return len;
}



// Given a directory, read all the files in this directory
void readDir(ULONG clusterNum, int loop) {
    int i;
    int j;
    int k;
    char name[12];
    char nameNoSpaces[12];
    char nameNoSpace[12];
    DIR * currEntry;

    ULONG FATSecOffset = (clusterNum*4);
    ULONG nextCluster;

    // Get base sector
    ULONG baseSector = returnFirstSector(clusterNum);
    //printf("Cluster: %ld\n", clusterNum);
    /*printf("Base Sector 1: %ld\n", baseSector);
    printf("Num DirectEntries per Sector: %d\n", dps);*/
    // Read sector in each cluster
    for (i = 0; i < spc; i++) {
        // Read Dir Entry for each sector
        for (j = 0; j < dps; j++) {
            readEntry(baseSector+i, buffer, spc, j);
            // Read current dirEntry in sector, null terminate the name
            currEntry = (DIR * )buffer;
            memcpy(name, currEntry->DIR_Name, 11);
            name[11] = '\0';

            // Remove space in name
            removeSpaces(name, nameNoSpace);
            
            //memset(nameNoSpace, 0, 12);
            //removeSpaces(name, nameNoSpace);

            if ((currEntry->DIR_Attr == 16 || currEntry->DIR_Attr == 32) && j > 2) {
                printf("|");
                for (k = 0; k < loop*2; k++) {
                    printf("_");
                }

                /*printf("Attribute: %ld\n", currEntry->DIR_Attr);
                printf("Next Cluster Num: %d\n",currEntry->DIR_FstClusLO);
                getchar();*/
                if (currEntry->DIR_Attr == 16) {
                    printf("Directory: %s\n", nameNoSpace);
                    readDir(currEntry->DIR_FstClusLO, loop+1);
                } else if (currEntry->DIR_Attr == 32) {
                    appendDot(nameNoSpace);
                    printf("File: %s\n", nameNoSpace);
                }
            }
        }
    }

    // Insert thing here to check FAT to see if it continues
    //printf("Next cluster chain: %ld", FAT[clusterNum]);
    readFAT(reservedSec, (unsigned char *)FAT, FATSecOffset);
    nextCluster = FAT[0];
    nextCluster = nextCluster & 0x0FFFFFFF;

    /*printf("0x%lx, %ld\n", nextCluster, nextCluster);
        printf("Next cluster: %ld\n", nextCluster);
        printf("Sector Offset: %ld\n", FATSecOffset);*/
    if (nextCluster < 0xffffff7) {
        /*printf("0x%lx, %ld\n", nextCluster, nextCluster);
        printf("Next cluster: %ld\n", nextCluster);
        printf("Sector Number: %ld\n", FATSecNum);
        printf("Sector Offset: %ld\n", FATSecOffset);
        getchar();*/
        readDir(nextCluster, loop);
    } 
}

// Given a directory, find a file/directory in this directory
bool findFile(ULONG clusterNum, char *fileName, DIR *entry) {
    int i;
    int j;
    int k;
    char name[12];
    char nameNoSpace[12];
    DIR * currEntry;
    ULONG foundClusterNum = -1;
    ULONG currentClusterNum = -1;
    bool success = false;
    ULONG FATSecOffset = (clusterNum*4);
    ULONG nextCluster;

    // Get base sector
    ULONG baseSector = returnFirstSector(clusterNum);
    //printf("Cluster: %ld\n", clusterNum);
    /*printf("Base Sector 1: %ld\n", baseSector);
    printf("Num DirectEntries per Sector: %d\n", dps);*/
    // Read sector in each cluster
    for (i = 0; i < spc && !success; i++) {
        // Read Dir Entry for each sector
        for (j = 0; j < dps && !success; j++) {
            readEntry(baseSector+i, buffer, spc, j);
            // Read current dirEntry in sector, null terminate the name
            currEntry = (DIR * )buffer;
            memcpy(name, currEntry->DIR_Name, 11);
            name[11] = '\0';

            // Remove space in name
            removeSpaces(name, nameNoSpace);
            
            // Append dot if file
            if (currEntry->DIR_Attr == 32) {
                appendDot(nameNoSpace);
            }

            // Print whatever is contained in dirEntry
            if ((currEntry->DIR_Attr == 16 || currEntry->DIR_Attr == 32) && j > 2) {
                if (strcasecmp(nameNoSpace, fileName) == 0) {
                    success = true;
                    memcpy(entry, currEntry, sizeof(DIR));
                }
            }
        }
    }

    // See if fat cluster chain continues
    readFAT(reservedSec, (unsigned char *)FAT, FATSecOffset);
    nextCluster = FAT[0];
    nextCluster = nextCluster & 0x0FFFFFFF;

    if (nextCluster < 0xffffff7 && !success) {
        findFile(nextCluster, fileName, entry);
    }

    // Check fat
    return success; 
}

// Given a directory, read all the files in this directory
void readFile(ULONG clusterNum) {
    int i;
    int j;
    int k;
    char name[12];
    char nameNoSpace[12];
    DIR * currEntry;
    ULONG nextCluster;
    ULONG FATSecNum = reservedSec + (clusterNum*4/bps);
    ULONG FATSecOffset = (clusterNum*4);

    // Get base sector
    ULONG baseSector = returnFirstSector(clusterNum);

    
    // Read sector in each cluster
    for (i = 0; i < spc; i++) {
        // Read Dir Entry for each sector
        for (j = 0; j < dps; j++) {
            readEntry(baseSector+i, buffer, spc, j);

            // Read current dirEntry in sector, null terminate the name
            currEntry = (DIR * )buffer;

            // Print file contents
            printf("%s", currEntry->DIR_Name);
        }
    } 

    // See if fat cluster chain continues
    readFAT(reservedSec, (unsigned char *)FAT, FATSecOffset);
    nextCluster = FAT[0];
    nextCluster = nextCluster & 0x0FFFFFFF;

    if (nextCluster < 0xffffff7) {
        readFile(nextCluster);
    }
}

int readFAT(ULONG sectorNum, unsigned char *buffer, ULONG offset) 
{
	int dest, len;     /* used for error checking only */

    // Starting position in entry
	dest = lseek(fileID, sectorNum*bps+offset, SEEK_SET);
    // Read the entryCluster
	len = read(fileID, buffer, 32);
    //printf("Len: %d\n", len);
	return len;
}

// Returns the first sector number for cluster
ULONG returnFirstSector (ULONG cluster) {
    return (ULONG)(dataSecStart + (cluster-2) * spc);
} 

// Returns cluster number from direct entry
ULONG getClusterNum(DIR dirEntry){
	return ((dirEntry.DIR_FstClusHI<<16) + dirEntry.DIR_FstClusLO);
}

// Remove spaces from given string
void removeSpaces(char source[], char dest[]) {
    int i;
    int j = 0;

    for (i = 0; i < strlen(source); i++) {
        if (source[i] != ' ') {
            dest[j] = source[i];
            j++;
        }
    }
    dest[j] = '\0';
}

void appendDot(char file[]) {
    int i;
    char temp = '.';
    char temp2;
    for (i = strlen(file)-3; i < strlen(file)+1; i++) {
        temp2 = file[i];
        file[i] = temp;
        temp = temp2;
    }
}