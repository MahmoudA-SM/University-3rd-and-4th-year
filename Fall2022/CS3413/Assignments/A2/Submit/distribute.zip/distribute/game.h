#ifndef GAME_H

#include "player.h"
#include "caterpiller_list.h"
#include "bullet_list.h"
#include <pthread.h>

#define MAX_BULLET 10

typedef enum
{
    QUIT_KEY,
    WIN,
    LOOSE
} GAME_EXIT_STATUS;

typedef struct
{
    bool game_running;
    int event_count;

    GAME_EXIT_STATUS exit_code;

    Player *player;
    Caterpiller_List *list;
    Bullet_List * bullet_list;

    pthread_mutex_t global_mutex;
} Game_State;

#define GAME_H
#endif