#ifndef MATH_H

typedef union
{
    struct
    {
        int x;
        int y;
    };
    int e[2];
}v2;

#define MATH_H
#endif