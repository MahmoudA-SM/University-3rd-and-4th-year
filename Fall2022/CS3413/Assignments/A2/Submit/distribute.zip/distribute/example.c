
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/select.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "console.h"
#include "example.h"
#include "game.h"

#define GAME_ROWS 24
#define GAME_COLS 80

Game_State game_state = {};

/**** DIMENSIONS MUST MATCH the ROWS/COLS */

char *GAME_BOARD[] = {
    "",
    "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-caterpiller!=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "", "",
    "\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"",
    "",
    "",
    "",
    "",
    "",
    "",
    ""};

#define ENEMY_HEIGHT 2
#define PLAYER_BODY_HEIGHT 3
#define PLAYER_BODY_WIDTH 3

void *update_scores()
{
  while (game_state.game_running)
  {

    char new_scr[GAME_COLS];
    snprintf(new_scr,GAME_COLS, "             Score: %d        Lives: %d ", game_state.player->score, game_state.player->lives);
    putString(new_scr, 0, 0, GAME_COLS-1);

    sleepTicks(40);
  }
  return NULL;
}

void exampleRun()
{
  if (consoleInit(GAME_ROWS, GAME_COLS, GAME_BOARD)) // start the game (maybe need to do this elsewhere...)
  {
    // only run one example at once (comment others out).
    // these examples should be removed in your final submission!
    game_state.game_running = true;
    game_state.player = initilize_player(4, PLAYER_BODY_HEIGHT, PLAYER_BODY_WIDTH, 20, 20);
    game_state.list = &(Caterpiller_List){.head = NULL};
    game_state.bullet_list = &(Bullet_List){.head = NULL};

    pthread_t player_t, player_animate;
    pthread_t caterpiller_insert_t;
    pthread_t refresh_game_t;
    pthread_t score_t;
    pthread_t upkeep_t;

    // pthread_create(&enemy, NULL, moveEnemyExampleT, (void*)pos1);
    pthread_create(&player_t, NULL, playerControlExample, NULL);
    pthread_create(&refresh_game_t, NULL, refresh_game, NULL);
    pthread_create(&player_animate, NULL, update_player, NULL);
    pthread_create(&score_t,NULL, update_scores, NULL);
    pthread_create(&upkeep_t, NULL, upkeep_thread, NULL);
    pthread_create(&caterpiller_insert_t, NULL, generate_caterpiller, NULL);


    pthread_join(player_animate, NULL);
    pthread_join(score_t, NULL);
    pthread_join(player_t, NULL);

    pthread_cancel(caterpiller_insert_t);


    pthread_join(refresh_game_t, NULL);

    pthread_join(upkeep_t, NULL);

    switch (game_state.exit_code)
    {
    case QUIT_KEY:
    {
      putBanner("Thanks for playing! ");
    }
    break;

    case WIN:
    {
      putBanner("Congras you won! ");
    }
    break;

    case LOOSE:
    {
      putBanner("You lost! ");
    }
    break;
    }

    // moveEnemyExample(1,1);
    // playerControlExample();
    // multipleEnemyExample();

    finalKeypress(); /* wait for final key before killing curses and game */
  }
  pthread_mutex_destroy(&game_state.player->mutex);

  Bullet *b = game_state.bullet_list->head;
  while (b)
  {
    pthread_mutex_destroy(&b->mutex);
    b = b->next;
  }

  Caterpiller *c = game_state.list->head;
  while (c)
  {
    pthread_mutex_destroy(&c->mutex);
    c = c->next;
  }

  consoleFinish();
  return;
}

void *refresh_game()
{
  while (game_state.game_running)
  {
    
    consoleRefresh();
    sleepTicks(5);
  }
  return NULL;
}

void *update_player()
{
  while (game_state.game_running)
  {
    Player *player = game_state.player;
    pthread_mutex_lock(&player->mutex);
    animate_player(player);
    consoleDrawImage(player->position.y, player->position.x, get_body_player(player), player->size.y);
    pthread_mutex_unlock(&player->mutex);
    sleepTicks(10);
  }
  return NULL;
}

void * upkeep_thread(){
  while (game_state.game_running)
  {
    // Check if any bullets are out of bounds
    Bullet *bul = game_state.bullet_list->head;

    if (get_list_size(game_state.list) == 0 && get_bullet_list_size(game_state.bullet_list) > 0)
    {
      game_state.game_running = false;
      game_state.exit_code = WIN;
      return NULL;
    }
    while (bul)
    {
      if (bul->hit)
      {
        Bullet *temp = bul->next;
        pthread_join(bul->thread, NULL);
        consoleClearImage(bul->position.y, bul->position.x, 1, 1);
        delete_bullet_position(game_state.bullet_list, bul->position);
        pthread_mutex_destroy(&bul->mutex);
        bul = temp;
      }
      else
      {
        bul = bul->next;
      }
    }


    //Check if caterpiller is hit
    //If yes then 

    Caterpiller* curr = game_state.list->head;

    while (curr != NULL)
    {

      // If size of the catterpiller is less than 5 then delete it
      pthread_mutex_lock(&curr->mutex);

      if (curr->hit)
      {
        pthread_mutex_lock(&game_state.player->mutex);
        game_state.player->score++;
        pthread_mutex_unlock(&game_state.player->mutex);
      }

      if (curr->hit && curr->size <= 5)
      {
        Caterpiller *temp = curr->next;
        consoleClearImage(curr->position.y, curr->position.x, 1, curr->size);
        pthread_join(curr->thread, NULL);
        pthread_mutex_unlock(&curr->mutex);
        pthread_mutex_destroy(&curr->mutex);
        delete_position(game_state.list, curr->position);
        curr = temp;
      }
      else
      {
        pthread_mutex_unlock(&curr->mutex);
        curr = curr->next;
      }
    }

    sleepTicks(10);
  }
  return NULL;
}

void *generate_caterpiller()
{

  while (game_state.game_running)
  {
    Caterpiller *new_c = init_caterpiller((v2){.x = 3, .y = 3}, 1, 15, 1);
    insert_last(game_state.list, new_c);
    pthread_create(&new_c->thread, NULL, caterpiller_thread, (void *)new_c);

    sleepTicks(2000);
  }
  return NULL;
}

void *caterpiller_thread(void *caterpiller_v)
{
  Caterpiller* caterpiller = (Caterpiller*)caterpiller_v;
  int bullet_tick = 0;
  while (game_state.game_running)
  {

    bullet_tick++;
    if (bullet_tick >= 10)
    {
      Bullet *new_b = init_bullet((v2){.x = caterpiller->position.x , .y = caterpiller->position.y + 1}, false);
      insert_bullet_last(game_state.bullet_list, new_b);
      pthread_create(&new_b->thread, NULL, bullet_thread, (void *)new_b);
      bullet_tick = 0;
    }

    Bullet* b = collision_bullet(caterpiller);

    pthread_mutex_lock(&caterpiller->mutex);
    consoleClearImage(caterpiller->position.y, caterpiller->position.x, 1, caterpiller->size);

    if (b != NULL)
    {

      if (b->is_player)
      {
        b->hit = true;
        caterpiller->hit = true;
        game_state.player->score++;

        if (caterpiller->size > 5)
        {
          caterpiller->size -= 5;
          caterpiller->hit = false;
          consoleClearImage(caterpiller->position.y, caterpiller->position.x, 1, caterpiller->size);
          Caterpiller *new_c = init_caterpiller((v2){.x = caterpiller->position.x + caterpiller->size + 5, .y = caterpiller->position.y}, caterpiller->direction, caterpiller->size, caterpiller->speed + 1);

          insert_last(game_state.list, new_c);
          pthread_create(&new_c->thread, NULL, caterpiller_thread, (void *)new_c);
        }
        else
        {
          pthread_mutex_unlock(&caterpiller->mutex);
          return NULL;
        }
      }
    }
    caterpiller->position.x += (caterpiller->direction * caterpiller->speed);
    if ((caterpiller->position.x > (GAME_COLS - (caterpiller->size + caterpiller->speed)) ||
         (caterpiller->position.x <= 0)))
    {
      caterpiller->position.y++;

      if (caterpiller->direction == -1)
      {
        caterpiller->position.x = 0;
        caterpiller->direction = 1;
      }
      else
      {
        caterpiller->position.x = (GAME_COLS - (caterpiller->size + caterpiller->speed));
        caterpiller->direction = -1;
      }
    }
    putString(get_caterpiller_body(caterpiller), caterpiller->position.y, caterpiller->position.x, caterpiller->size);
    pthread_mutex_unlock(&caterpiller->mutex);
    sleepTicks(10);
  }
  return NULL;
}

/**
 * Checks if the caterpiller has collided with any of the bullets
 */
Bullet *collision_bullet(Caterpiller *cat)
{
  Bullet *curr = game_state.bullet_list->head;
  pthread_mutex_lock(&cat->mutex);

  while (curr != NULL)
  {
    if (curr->is_player)
    {
      pthread_mutex_lock(&curr->mutex);
      if ((curr->position.y == cat->position.y) &&
          (curr->position.x >= cat->position.x) &&
          (curr->position.x <= cat->position.x + cat->size))
      {
        pthread_mutex_unlock(&curr->mutex);
        pthread_mutex_unlock(&cat->mutex);
        return curr;
      }
      pthread_mutex_unlock(&curr->mutex);
    }
    curr = curr->next;
  }
  pthread_mutex_unlock(&cat->mutex);
  return NULL;
}

/**
 * 
Caterpiller *collision_caterpiller(Bullet *bull)
{
  Caterpiller *cat = game_state.list->head;

  while (cat != NULL)
  {
    if (bull->is_player)
    {
      pthread_mutex_lock(&cat->mutex);
      if ((bull->position.y == cat->position.y) &&
          (bull->position.x >= cat->position.x) &&
          (bull->position.x <= cat->position.x + cat->size))
      {
        pthread_mutex_unlock(&cat->mutex);
        return cat;
      }
      pthread_mutex_unlock(&cat->mutex);
    }
    cat = cat->next;
  }
  return NULL;
}
*/

void *bullet_thread(void *bullet_v)
{

  Bullet* bullet = (Bullet*)bullet_v;
  while (game_state.game_running)
  {
    pthread_mutex_lock(&bullet->mutex);
    consoleClearImage(bullet->position.y, bullet->position.x, 1, 1);

    if(!bullet->is_player && (bullet->position.y > GAME_ROWS-15)){

      v2 BPos = bullet->position;

      pthread_mutex_lock(&game_state.player->mutex);
      v2 PPos = game_state.player->position;

      if ((BPos.x >= PPos.x) && (BPos.x <= PPos.x + game_state.player->size.x) &&
          (BPos.y >= PPos.y) && (BPos.y <= PPos.y + game_state.player->size.y))
      {
        game_state.player->lives -= 1;


        if(game_state.player->lives == 0){
          game_state.game_running = false;
          game_state.exit_code = LOOSE;
        }

        pthread_mutex_unlock(&game_state.player->mutex);
        bullet->hit = true;
        return NULL;
      }
      pthread_mutex_unlock(&game_state.player->mutex);
    }

    if (bullet->is_player)
    {
      bullet->position.y--;
    }
    else
    {
      bullet->position.y++;
    }

    if ((bullet->position.x < 0 || bullet->position.x >= GAME_COLS) || (bullet->position.y < 0 || bullet->position.y >= GAME_ROWS))
    {
      bullet->hit = true;
      return NULL;
    }
    putString(get_bullet_body(bullet), bullet->position.y, bullet->position.x, 1);
    pthread_mutex_unlock(&bullet->mutex);
    sleepTicks(10);
  }
 return NULL;
}

void *playerControlExample()
{
  fd_set set; /* what to check for our select call */

  // consoleDrawImage(player->position.y , player->position.x, get_body_player(player), PLAYER_BODY_HEIGHT); //draw the enemy at 10,10 but move them along once per animation image
  consoleRefresh(); //reset the state of the console drawing tool

  while (game_state.game_running)
  {
    /* setup select to listen to stdin. necessary as getchar
      is blocking and cannot be easily unblocked, e.g.,
                  to end the game*/
    /* re-set each time as it can get overwritten */
    // essentially, wait for a key, or a timeout
    // read man page for pselect to understand all of this!
    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);
    struct timespec timeout = getTimeout(1); /* duration of one tick */
    game_state.event_count = pselect(FD_SETSIZE, &set, NULL, NULL, &timeout, NULL);

    /* check if we timed out, or, event happened.
      also, game may have ended while we waited */
    if (game_state.game_running && game_state.event_count >= 1)
    {
      char c = getchar();
      Player *player = game_state.player;

      // this move code is too simple for when we get to threads...
      // there's also no error checking
      // we'll have to add in some protection...what are the critical resources here?
      pthread_mutex_lock(&player->mutex);
      consoleClearImage(player->position.y, player->position.x, player->size.x, player->size.y);
      v2 new_pos = player->position;
      pthread_mutex_unlock(&player->mutex);
      if (c == MOVE_LEFT)
      {
        new_pos.x -= 1;
      }
      else if (c == MOVE_RIGHT)
      {
        new_pos.x += 1;
      }
      else if (c == MOVE_DOWN)
      {
        new_pos.y += 1;
      }
      else if (c == MOVE_UP)
      {
        new_pos.y -= 1;
      }
      else if (c == QUIT)
      {
        game_state.game_running = false;
        game_state.exit_code = QUIT_KEY;
      }
      else if (c == SHOOT)
      {
        Bullet *new_b = init_bullet(player->position, true);
        insert_bullet_last(game_state.bullet_list, new_b);
        pthread_create(&new_b->thread, NULL, bullet_thread, (void*)new_b);
      }
      pthread_mutex_lock(&player->mutex);
      if ((new_pos.y > 16) && (new_pos.x > 0) && (new_pos.y < (GAME_ROWS-3)) && (new_pos.x < (GAME_COLS - 3)))
      {
        player->position = new_pos;
      }
      pthread_mutex_unlock(&player->mutex);
      // NOT THREADED
      // just draw player...using enemy from earlier

    } /* end select bypass */

  } /* game loop*/
  sleepTicks(10);
  return NULL;
}
