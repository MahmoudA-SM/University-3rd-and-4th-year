#include "math.h"
#include "stdlib.h"
#include "bullet_list.h"

char bullet_body_up[1] = "^";
char bullet_body_down[1] = "\"";

Bullet *init_bullet(v2 position, bool is_player)
{
    Bullet *ret = (Bullet *)malloc(sizeof(Bullet));
    ret->is_player = is_player;
    ret->position = position;
    ret->next = NULL;
    ret->hit = false;
    pthread_mutex_init(&ret->mutex, NULL);
    return ret;
}

void insert_bullet_last(Bullet_List *list, Bullet *new_c)
{
    if (list->head == NULL)
    {
        list->head = new_c;
    }
    else
    {
        Bullet *curr = list->head;
        while (curr->next != NULL)
        {
            curr = curr->next;
        }
        curr->next = new_c;
    }
}

void delete_bullet_position(Bullet_List *list, v2 position)
{
    if (list->head == NULL)
    {
    }
    else
    {
        Bullet *curr = list->head;
        Bullet *prev = list->head;

        if (curr->position.x == position.x && curr->position.y && position.y)
        {
            Bullet *temp = curr;
            list->head = curr->next;
            free(temp);
            return;
        }
        else
        {
            curr = curr->next;
        }

        while (curr->next != NULL)
        {
            if (curr->position.x == position.x && curr->position.y && position.y)
            {
                Bullet *temp = curr;
                prev->next = curr->next;
                free(temp);
            }
            curr = curr->next;
            prev = prev->next;
        }
    }
}

int get_bullet_list_size(Bullet_List *list)
{
    int count = 0;
    Bullet *curr = list->head;
    while (curr)
    {
        count++;
        curr = curr->next;
    }
    return count;
}

char* get_bullet_body(Bullet* b){
    if(b->is_player){
        return (char*)bullet_body_up;
    }else{
        return (char*)bullet_body_down;
    }
}
