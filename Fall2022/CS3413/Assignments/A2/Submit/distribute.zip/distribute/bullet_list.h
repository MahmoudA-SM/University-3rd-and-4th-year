#ifndef BULLET_LIST
#include "math.h"
#include "stdlib.h"
#include "stdbool.h"
#include "pthread.h"

struct Bullet
{
    v2 position;
    bool is_player;
    bool hit;
    pthread_t thread;
    struct Bullet *next;
    pthread_mutex_t mutex;
};
typedef struct Bullet Bullet;

typedef struct
{
    Bullet *head;
} Bullet_List;

Bullet *init_bullet(v2 , bool);
void insert_bullet_last(Bullet_List *list, Bullet *new_b);
void delete_bullet_position(Bullet_List *list, v2 position);
char *get_bullet_body(Bullet*);
int get_bullet_list_size(Bullet_List *list);

#define BULLET_LIST
#endif