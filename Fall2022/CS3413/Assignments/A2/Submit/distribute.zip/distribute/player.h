#ifndef PLAYER_H

#include "stdlib.h"
#include "math.h"
#include "stdbool.h"
#include "pthread.h"

typedef struct 
{
    int score;
    int lives;

    v2 size;
    v2 position;
    bool blink;
    int dash_pos;
    pthread_mutex_t mutex;
}Player;

Player* initilize_player(int lives, int height, int width, int x, int y);

char ** get_body_player(Player *);
void animate_player(Player*);

#define PLAYER_H
#endif