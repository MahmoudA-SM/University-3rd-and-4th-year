#include "player.h"
#include "string.h"
#include "game.h"
#include "console.h"

#define PLAYER_HEIGHT 4
#define PLAYER_WIDTH 4
#define PLAYER_ANIM_COUNT 6

char *player_body_anim[PLAYER_ANIM_COUNT][PLAYER_WIDTH] = {
    {"[@]",
     "-==",
     "/ \\"},
    {"[0]",
     "=-=",
     "/ \\"},
    {"[@]",
     "==-",
     "/ \\"},
    {"[0]",
     "-==",
     "/ \\"},
    {"[@]",
     "=-=",
     "/ \\"},
    {"[0]",
     "==-",
     "/ \\"}};

Player *initilize_player(int lives, int height, int width, int x, int y)
{
    Player *ret = (Player *)malloc(sizeof(Player));
    ret->score = 0;
    ret->blink = false;
    ret->dash_pos = 0;
    ret->lives = lives;
    ret->size = (v2){.y = height, .x = width};
    ret->position = (v2){.x = x, .y = y};
    pthread_mutex_init(&ret->mutex, NULL);
    return ret;
}

void animate_player(Player* p){
    p->blink = !p->blink;
    p->dash_pos++;
    if (p->dash_pos >= 3)
    {
        p->dash_pos = 0;
    }
}

char **get_body_player(Player *p)
{
    return (char **)player_body_anim[p->dash_pos * (p->blink ? 1 : 2)];
}
