
#include <stdio.h>
#include "example.h" 

int main(int argc, char**argv) 
{
	exampleRun();
	printf("done!\n");
}
