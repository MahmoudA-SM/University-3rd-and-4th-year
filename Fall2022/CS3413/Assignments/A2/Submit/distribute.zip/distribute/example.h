#ifndef EXAMPLE_H
#define EXAMPLE_H

#include <pthread.h>
#include "caterpiller_list.h"
#include "bullet_list.h"

//will probably want a file just for game globals. There should be a lot!
#define MOVE_LEFT 'a'
#define MOVE_RIGHT 'd'
#define MOVE_UP 'w'
#define MOVE_DOWN 's'
#define SHOOT ' '
#define QUIT 'q'

void * update_player();

void * update_scores();
void * upkeep_thread();
Caterpiller *collision_caterpiller(Bullet *bull);
void * update_collision();
void * refresh_game();
void exampleRun();
void *generate_caterpiller();
void moveEnemyExample();
void *playerControlExample();
void multipleEnemyExample();
void *caterpiller_thread();
void *bullet_thread();
int get_list_size(Caterpiller_List *list);
void* moveEnemyExampleT(void *v);
Bullet *collision_bullet(Caterpiller * cat);

#endif
