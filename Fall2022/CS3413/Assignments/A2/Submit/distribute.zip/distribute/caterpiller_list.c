#include "math.h"
#include "stdlib.h"
#include "stdbool.h"
#include "caterpiller_list.h"

char caterpiller_body1[15] = {"CDCDCDCDCDCDCDC"};
char caterpiller_body2[15] = {"DCDCDCDCDCDCDCD"};

Caterpiller *init_caterpiller(v2 position, int direction, int size, int speed)
{
    Caterpiller *ret = (Caterpiller *)malloc(sizeof(Caterpiller));
    ret->direction = direction;
    ret->position = position;
    ret->size = size;
    ret->hit = false;
    ret->speed = speed;
    ret->anim  = false;
    pthread_mutex_init(&ret->mutex, NULL);
    ret->next = NULL;
    return ret;
}

void insert_last(Caterpiller_List *list, Caterpiller *new_c)
{
    if (list->head == NULL)
    {
        list->head = new_c;
    }
    else
    {
        Caterpiller *curr = list->head;
        while (curr->next != NULL)
        {
            curr = curr->next;
        }
        curr->next = new_c;
    }
}

void insert_first(Caterpiller_List *list, Caterpiller *new_c)
{
    if (list->head == NULL)
    {
        list->head = new_c;
    }
    new_c->next = list->head;
    list->head = new_c;
}

void delete_position(Caterpiller_List *list, v2 position)
{
    if (list->head == NULL)
    {
    }
    else
    {
        Caterpiller *curr = list->head;
        Caterpiller *prev = list->head;

        if (curr->position.x == position.x && curr->position.y && position.y)
        {
            Caterpiller *temp = curr;
            list->head = curr->next;
            free(temp);
        }
        else
        {
            curr = curr->next;
        }

        while (curr->next != NULL)
        {
            if (curr->position.x == position.x && curr->position.y && position.y)
            {
                Caterpiller *temp = curr;
                prev->next = curr->next;
                free(temp);
            }
            curr = curr->next;
            prev = prev->next;
        }
    }
}

int get_list_size(Caterpiller_List *list)
{
    int count = 0;
    Caterpiller *curr = list->head;
    while (curr)
    {
        count++;
        curr = curr->next;
    }
    return count;
}

char *get_caterpiller_body(Caterpiller* cat)
{
    if(cat->anim){
        cat->anim = false;
        return (char*)caterpiller_body1;
    }else{
        cat->anim = true;
        return (char*)caterpiller_body2;
    }
}
