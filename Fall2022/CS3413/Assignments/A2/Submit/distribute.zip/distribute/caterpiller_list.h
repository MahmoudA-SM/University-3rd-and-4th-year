#ifndef CATERPILLER_LIST
#include "math.h"
#include "stdlib.h"
#include "stdbool.h"
#include "pthread.h"

#define MAX_CATERPILLER 20

struct Caterpiller
{
    v2 position;
    int direction;
    int speed;
    int size;
    bool hit;
    bool anim;
    struct Caterpiller *next;
    pthread_mutex_t mutex;
    pthread_t thread;
};
typedef struct  Caterpiller Caterpiller ;

typedef struct
{
    Caterpiller *head;
} Caterpiller_List;


Caterpiller *init_caterpiller(v2 position, int direction, int size, int speed);
void insert_last(Caterpiller_List *list, Caterpiller *new_c);
void insert_first(Caterpiller_List *list, Caterpiller *new_c);
void delete_position(Caterpiller_List *list, v2 position);
char* get_caterpiller_body(Caterpiller* cat);
int get_list_size(Caterpiller_List *list);

#define CATERPILLER_LIST
#endif