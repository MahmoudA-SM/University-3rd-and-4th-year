#include <stdio.h>
#include <hellomake.h>
int myPrintHelloMake(void)
{
	printf("Hello makefiles! %d\n", MYNUM);
	return SUCCESS;
}
