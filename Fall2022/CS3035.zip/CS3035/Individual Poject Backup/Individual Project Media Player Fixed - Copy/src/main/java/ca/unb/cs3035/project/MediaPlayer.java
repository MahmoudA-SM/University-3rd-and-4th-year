package ca.unb.cs3035.project;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.concurrent.TimeUnit;

/**
 *
 * @author Mahmoud
 */
public class MediaPlayer extends Application {

    MediaPlayerController mpc = new MediaPlayerController();
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("MediaPlayer.fxml"));


        StackPane spalshScreen = FXMLLoader.load(getClass().getResource("SplashScreen.fxml"));
        spalshScreen.setPrefHeight(400);
        spalshScreen.setPrefWidth(400);




        FadeTransition fadeIn = new FadeTransition(Duration.seconds(2.5), spalshScreen);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.setCycleCount(1);

        FadeTransition fadeOut = new FadeTransition(Duration.seconds(3), spalshScreen);
        fadeOut.setFromValue(1);
        fadeOut.setToValue(0);
        fadeOut.setCycleCount(1);

        fadeIn.play();
        Scene scene = new Scene(spalshScreen);
        stage.setScene(scene);

        fadeIn.setOnFinished(event -> {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            fadeOut.play();
        });

        fadeOut.setOnFinished(event -> {
            stage.setScene(new Scene(root, 600, 500));
        });


        stage.setTitle("MP Media Player");

        scene.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount() == 2){
                    stage.setFullScreen(true);
                }
            }
        });



        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}