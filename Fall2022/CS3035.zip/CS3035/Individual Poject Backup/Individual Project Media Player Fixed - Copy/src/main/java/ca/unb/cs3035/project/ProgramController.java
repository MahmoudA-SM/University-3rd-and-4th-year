package ca.unb.cs3035.project;

import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.util.ResourceBundle;

public class ProgramController {
    private MediaPlayerModel mpm = new MediaPlayerModel();
    private MediaPlayerView mpv = new MediaPlayerView(mpm);

    private BorderPane borderPane;

    private VBox vBox;
    private HBox hBox;

    public ProgramController(MediaPlayerModel mpm, MediaPlayerView mpv){
        this.mpm = mpm;
        this.mpv = mpv;

    }


    public void setBorderPane(BorderPane borderPane){
        this.borderPane = borderPane;
        System.out.println(borderPane.getChildren());
        vBox = (VBox) borderPane.getChildren().get(1);
        hBox = (HBox) vBox.getChildren().get(1);
    }

    public VBox getvBox() {
        return vBox;
    }

    public HBox gethBox() {
        return hBox;
    }

    public void openFile() {
    }
}
