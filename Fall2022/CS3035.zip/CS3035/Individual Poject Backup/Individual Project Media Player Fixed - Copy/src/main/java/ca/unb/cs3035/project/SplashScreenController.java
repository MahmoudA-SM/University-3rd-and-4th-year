package ca.unb.cs3035.project;

public class SplashScreenController {

//    public void loadSplashScreen(){
//        try{
//            //Load splash screen view FXML
//            StackPane pane = FXMLLoader.load(getClass().getResource(("SplashScreen.fxml")));
//            //Add it to root container (Can be StackPane, AnchorPane etc)
//
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//
//    }
}
