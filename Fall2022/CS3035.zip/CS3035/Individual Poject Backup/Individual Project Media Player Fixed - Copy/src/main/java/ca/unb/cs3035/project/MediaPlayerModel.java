package ca.unb.cs3035.project;

public class MediaPlayerModel {
}
