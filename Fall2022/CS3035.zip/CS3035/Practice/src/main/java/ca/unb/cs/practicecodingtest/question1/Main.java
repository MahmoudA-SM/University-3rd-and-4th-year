package ca.unb.cs.practicecodingtest.question1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * Read Coding Question 1 in the README.md file.
 * Complete the start method below to complete the interface.
 * Remember to start by writing complete logic first, don't worry about errors.
 * You can fix your errors afterwards if you have time.
 */
public class Main extends Application {
    private TextField textField;
    private Button setter;
    private Rectangle rect;
    @Override
    public void start(Stage primaryStage) throws Exception{
        textField = new TextField("100.0");
        setter = new Button("set side");
        setter.setOnAction(this::modifySquare);
        rect = new Rectangle(25,25,100,100);
        rect.setFill(Color.DARKBLUE);

        HBox hBox = new HBox(textField, setter);
        hBox.setAlignment(Pos.TOP_LEFT);

        hBox.setSpacing(10);

        StackPane stackPane = new StackPane(hBox, rect);
        stackPane.setPrefSize(400,400);


        Scene scene = new Scene(stackPane);

        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setTitle("Practice test ");
    }

    private void modifySquare(ActionEvent event) {
        double sideLength = Double.parseDouble(textField.getText());
        rect.setWidth(sideLength);
        rect.setHeight(sideLength);
    }

    public static void main(String[] args) {
        launch(args);
    }

}