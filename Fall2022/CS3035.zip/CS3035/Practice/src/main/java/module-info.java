module ca.unb.cs.practicecodingtest {
    requires javafx.controls;
    requires javafx.fxml;

    exports ca.unb.cs.practicecodingtest.question1;
}