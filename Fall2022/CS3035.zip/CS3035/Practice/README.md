# Practice Coding Test

Below is the requirement for a coding question that will be similar in style to your test.

This practice only contains 1 question. Your test will contain two.

You can practice with this question by giving yourself approximately 30 minutes to see if you can complete it and commit and push it back to your repo.

Remember to commit and push when you are done!

Write the complete code application for the interfaces pictured below, using JavaFX. Include code for creating and configuring the controls, laying out the controls in the window (as pictured), and linking the appropriate user events with the correct actions. You do not need to use an MVC architecture, and you do not need to necessarily get your code working 100% (see below).

## Strategy

For the test, you are advised to write the complete code logic, even if there are errors. For example, if you do not remember specific names of widgets or methods, make up a term and comment your code to explain your functionality. If you provide complete logic, but your code does not work, then you can still receive close to full marks.

**Note**: Images below are for guidance and illustration only. Small variations in terms of appearance that can be attributed to differences in systems or specific implementation approach are considered OK.

## Question 1

Write a program that displays a window. At the top of the Window is a TextField and a Button displayed horizontally. In the center of the screen is a Rectangle object displayed as a dark blue square (use a ```javafx.scene.shape.Rectangle``` for this instead of drawing on a Canvas) .

The window should be initially 400 pixels by 400 pixels. The rectangle/square will be centered in its area and will stay centered if the window is resized. The square will initially have a side length of 100 pixels.

The TextField will also initially display 100 pixels for the side length of the square, typing a new side length (you can assume a valid number is entered; i.e., no validation of input is needed) and clicking the "set side" button will setHeight and setWidth of the square to the value in the TextField.

<img src="https://user-images.githubusercontent.com/1709150/138189320-cd68b7f2-dfe4-4ebe-9dd3-afab10236788.png" width="400px" /> <img src="https://user-images.githubusercontent.com/1709150/138189401-80878b75-f1aa-43c6-a777-b57f0131aed7.png" width="400px" /> 

