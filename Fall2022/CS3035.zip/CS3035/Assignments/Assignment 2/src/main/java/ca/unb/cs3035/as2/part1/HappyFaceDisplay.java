package ca.unb.cs3035.as2.part1;

import ca.unb.cs3035.as2.Utility.ColorUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;

public class HappyFaceDisplay extends Pane {
    private Canvas canvas;
    private SimpleObjectProperty<Color> colorProperty;

    public HappyFaceDisplay(){
        super();
        colorProperty = new SimpleObjectProperty<Color>();
        colorProperty.set(Color.BLUE);
        canvas = new Canvas();
        getChildren().add(canvas);
    }

    @Override
    public void layoutChildren() {
        canvas.setWidth(this.getWidth());
        canvas.setHeight(this.getHeight());

        drawHappyFace(); // a method that you write
    }

    public void changeColorProperty(String colorName){
        int colorNameIndex = ColorUtility.getColorNameList().indexOf(colorName);
        colorProperty.set(ColorUtility.getColorList().get(colorNameIndex));
        layoutChildren();
    }

    public void drawHappyFace(){

        GraphicsContext gc = canvas.getGraphicsContext2D();
        double BORDER_SIZE = 10 * (getWidth()/600);
        gc.clearRect(0,0,getWidth(),getHeight());

        //Background
        gc.setFill(colorProperty.get());
        gc.fillRect(0,0,this.getWidth(), this.getHeight());


        gc.setLineWidth(8*getWidth()/600);
        //Face itself
        gc.setStroke(Color.BLACK);
        gc.strokeOval(BORDER_SIZE, BORDER_SIZE,getWidth()- BORDER_SIZE *2,getHeight()- BORDER_SIZE *2);

        double circleCenterX = getWidth()- 2*BORDER_SIZE;
        double circleCenterY = getHeight()- 2*BORDER_SIZE;

        gc.setLineWidth(getWidth()/600 * 3);

        double eyeWidth = 30*(getWidth()/600);
        double eyeHeight = 60*(getHeight()/600);

        //Left Eye
        gc.setFill(Color.BLACK);
        double leftEyeStartX = BORDER_SIZE + (circleCenterX/4);
        double leftEyeStartY = BORDER_SIZE + (circleCenterY/4);
        gc.fillRect(leftEyeStartX, leftEyeStartY, eyeWidth, eyeHeight);

        //Right Eye
        double rightEyeStartX = BORDER_SIZE - eyeWidth + circleCenterX * 3/4;
        double rightEyeStartY = circleCenterY / 4 + BORDER_SIZE;
        gc.fillRect(rightEyeStartX, rightEyeStartY, eyeWidth, eyeHeight);


        //Smile 😁
        double smileX = (circleCenterX / 4) + BORDER_SIZE;
        double smileY = (3 * circleCenterY /8) + BORDER_SIZE;
        gc.strokeArc(smileX, smileY, circleCenterX / 2, circleCenterY/2,180,180, ArcType.OPEN);

    }

}
