package ca.unb.cs3035.as2.part2;

import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;

public class MyFlowPane extends Pane {

    private double prefHeight, prefWidth, maxWidth, maxHeight, minWidth, minHeight, bottomRightCornerDim;
    public MyFlowPane()
    {
        super();
        //add in clipping to the pane
        Rectangle clipRectangle = new Rectangle();
        this.setClip(clipRectangle);
        this.layoutBoundsProperty().addListener((observable, oldValue, newValue) -> {
            clipRectangle.setWidth(newValue.getWidth());
            clipRectangle.setHeight(newValue.getHeight());
        });
    }
    public void setZero(){
        prefHeight = 0;
        prefWidth = 0;
        maxWidth = 0;
        maxHeight = 0;
        minWidth = 0;
        minHeight = 0;
    }
    @Override
    public void layoutChildren() {
        bottomRightCornerDim = 0;
        // first determine the size parameters for all children
        // by looping through and adding them up
        for (int i = 0; i < getChildren().size(); i++) {
            Region r = (Region) getChildren().get(i);
            prefHeight += r.getPrefHeight();
            maxHeight += r.getMaxHeight();
            minHeight += r.getMinHeight();

            prefWidth += r.getPrefWidth();
            maxWidth += r.getMaxWidth();
            minWidth += r.getMinWidth();
        }


        //next size the children as appropriate
        //use max dimensions if there is enough space horizontal space
        if (maxWidth <= this.getWidth())
        {

            for (int i = 0; i < getChildren().size(); i++) {
                Region r = (Region) getChildren().get(i);
                r.resize(r.getMaxWidth(), r.getMaxHeight());
                r.relocate(bottomRightCornerDim, bottomRightCornerDim);
                bottomRightCornerDim += r.getMaxWidth();
            }

        } else if (prefWidth <= this.getWidth()) {

            for (int i = 0; i < getChildren().size(); i++) {
                Region r = (Region) getChildren().get(i);
                r.resize(r.getPrefWidth(),r.getPrefHeight());
                r.relocate(bottomRightCornerDim, bottomRightCornerDim);
                bottomRightCornerDim += r.getPrefWidth();
            }
        }
        else {
            for (int i = 0; i < getChildren().size(); i++) {
                Region r = (Region) getChildren().get(i);
                r.resize(r.getMinWidth(),r.getMinHeight());
                r.relocate(bottomRightCornerDim, bottomRightCornerDim);
                bottomRightCornerDim += r.getMinWidth();
            }
        }
        setZero();
        //etc as described above
    }
}