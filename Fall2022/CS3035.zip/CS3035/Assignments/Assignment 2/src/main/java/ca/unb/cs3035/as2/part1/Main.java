package ca.unb.cs3035.as2.part1;

import ca.unb.cs3035.as2.Utility.ColorUtility;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class Main extends Application {
    public void start(Stage primaryStage) throws IOException {
        BorderPane root = (BorderPane) FXMLLoader.load(getClass().getResource("Interface.fxml"));
        root.setPrefWidth(746.8);
        root.setPrefHeight(642.4);
        //get components
        HappyFaceDisplay happyFace = (HappyFaceDisplay) root.getCenter();
        happyFace.setPadding(new Insets(10,10,10,10));
        happyFace.setPrefHeight(600);
        happyFace.setPrefWidth(600);

        ListView <String> listView = (ListView<String>) root.getRight();
        List<String> nameColors = (List<String>) ColorUtility.getColorNameList();
        ObservableList<String> observableList = FXCollections.observableList(nameColors);
        listView.setItems(observableList);
        Label size = (Label) root.getBottom();
        happyFace.heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                size.textProperty().bind(Bindings.concat(happyFace.getWidth(),",",happyFace.getHeight()));

            }
        });

        happyFace.widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                size.textProperty().bind(Bindings.concat(happyFace.getWidth(),",",happyFace.getHeight()));

            }
        });

        listView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    happyFace.changeColorProperty(newValue);
                }
        );

        Scene scene = new Scene(root);
        scene.setFill(Color.BLACK);
        
        primaryStage.setTitle("Assignment 2, Part 1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
