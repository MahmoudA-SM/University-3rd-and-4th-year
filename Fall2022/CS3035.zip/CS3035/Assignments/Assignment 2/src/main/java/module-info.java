module ca.unb.cs3035.as2 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ca.unb.cs3035.as2.part1 to javafx.fxml;
    exports ca.unb.cs3035.as2.part1;
    opens ca.unb.cs3035.as2.part2 to javafx.fxml;
    exports ca.unb.cs3035.as2.part2;
    exports ca.unb.cs3035.as2.Utility;
}