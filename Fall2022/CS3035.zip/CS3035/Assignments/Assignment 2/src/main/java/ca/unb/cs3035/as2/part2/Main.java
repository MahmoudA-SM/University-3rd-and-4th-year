package ca.unb.cs3035.as2.part2;

import ca.unb.cs3035.as2.Utility.ColorUtility;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Flow;

public class Main extends Application {
    private MyFlowPane flowPane;
    private ListView<String> listView;
    private String color;
    public void start(Stage primaryStage) throws IOException {
        BorderPane root = (BorderPane) FXMLLoader.load(getClass().getResource("Interface.fxml"));

        flowPane = (MyFlowPane) root.getCenter();

        VBox vBox = (VBox) root.getRight();
        vBox.setAlignment(Pos.CENTER);
        Button addFaceButton = (Button) vBox.getChildren().get(1);
        addFaceButton.setOnAction(this::addFace);
        Button clearAllButton = (Button) vBox.getChildren().get(2);
        clearAllButton.setOnAction((this::clearAll));

        listView = (ListView<String>) vBox.getChildren().get(0);
        List<String> nameColors = ColorUtility.getColorNameList();
        ObservableList<String> observableList = FXCollections.observableList(nameColors);
        listView.setItems(observableList);
        color = nameColors.get(12);
        listView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    color = newValue;
                }
        );



        Label size = (Label) root.getBottom();
        flowPane.heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                size.textProperty().bind(Bindings.concat(flowPane.getWidth(),",",flowPane.getHeight()));

            }
        });
        flowPane.widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                size.textProperty().bind(Bindings.concat(flowPane.getWidth(),",",flowPane.getHeight()));

            }
        });

        Scene scene = new Scene(root);


        primaryStage.setTitle("Assignment 2, Part 2");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void addFace(ActionEvent event)
    {
        HappyFaceDisplay happyFace = new HappyFaceDisplay();
        happyFace.changeColorProperty(color);
        flowPane.getChildren().add(happyFace);


    }

    public void clearAll(ActionEvent event)
    {
        flowPane.setZero();
        flowPane.getChildren().clear();
    }

    public static void main(String[] args) {
        launch(args);
    }
}