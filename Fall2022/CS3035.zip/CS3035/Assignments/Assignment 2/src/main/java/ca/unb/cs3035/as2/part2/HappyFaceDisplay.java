package ca.unb.cs3035.as2.part2;

import ca.unb.cs3035.as2.Utility.ColorUtility;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;

public class HappyFaceDisplay extends Pane {
    private Canvas canvas;
    private SimpleObjectProperty<Color> colorProperty;


    public HappyFaceDisplay(){
        super();
        colorProperty = new SimpleObjectProperty<Color>();
        colorProperty.set(Color.BLUE);
        canvas = new Canvas();
        getChildren().add(canvas);
        double prefHW = randprefWidthHeight();
        setPrefSize(prefHW,prefHW);
        double maxHW = randMaxHeightWidth();
        setMaxSize(maxHW,maxHW);
        double minHW = randminWidthHeight();
        setMinSize(minHW, minHW);

    }

    @Override
    public void layoutChildren() {
        canvas.setWidth(this.getWidth());
        canvas.setHeight(this.getHeight());

        drawHappyFace(); // a method that you write
    }

    public void changeColorProperty(String colorName){
        int colorNameIndex = ColorUtility.getColorNameList().indexOf(colorName);
        colorProperty.set(ColorUtility.getColorList().get(colorNameIndex));
        layoutChildren();
    }

    public void drawHappyFace(){

        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0,0,getWidth(),getHeight());

        //Background
        gc.setFill(colorProperty.get());
        gc.fillRect(0,0,this.getWidth(), this.getHeight());
        //Face itself
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(8*getWidth()/600);
        double BORDERSIZE = 10 * (getWidth()/600);


        gc.strokeOval(BORDERSIZE, BORDERSIZE,getWidth()- BORDERSIZE *2,getHeight()- BORDERSIZE *2);

        double centerofCircleX = getWidth()-2* BORDERSIZE;
        double centerofCircleY = getHeight()-2* BORDERSIZE;

        gc.setLineWidth(getWidth()/600 * 3);

        //Left Eye
        gc.setFill(Color.BLACK);
        double eyeWidth = 30*(getWidth()/600);
        double eyeHeight = 60*(getHeight()/600);
        double leftEyeStartX = BORDERSIZE + (centerofCircleX/4);
        double leftEyeStartY = BORDERSIZE + (centerofCircleY/4);
        gc.fillRect(leftEyeStartX, leftEyeStartY, eyeWidth, eyeHeight);

        //Right Eye
        double rightEyeStartX = BORDERSIZE - eyeWidth + centerofCircleX * 3/4;
        double rightEyeStartY = centerofCircleY / 4 + BORDERSIZE;
        gc.fillRect(rightEyeStartX, rightEyeStartY, eyeWidth, eyeHeight);

        //Smile 😁

        double smileX = (centerofCircleX / 4) + BORDERSIZE;
        double smileY = (3 * centerofCircleY /8) + BORDERSIZE;
        if(getWidth() == getMaxWidth())
            gc.strokeArc(smileX, smileY, centerofCircleX / 2, centerofCircleY/2,180,180, ArcType.OPEN);
        else if(getWidth() == getPrefWidth())
            gc.strokeLine(smileX, (3 * centerofCircleY /4) + BORDERSIZE,BORDERSIZE + centerofCircleX * 3/4, centerofCircleY* 3/ 4 + BORDERSIZE);
        else
            gc.strokeArc(smileX, smileY, centerofCircleX / 2, centerofCircleY/2,20, 140, ArcType.OPEN);

    }

    private double randMaxHeightWidth(){
        double min = 250;
        double max = 500;
        double randomHeightWidth = (double)Math.floor(Math.random()*(max-min+1)+min);
        return randomHeightWidth;
    }
    private double randprefWidthHeight(){
        double min = 100;
        double max = 200;
        double randomHeightWidth = (double)Math.floor(Math.random()*(max-min+1)+min);
        return randomHeightWidth;
    }
    private double randminWidthHeight(){
        double min = 10;
        double max = 80;
        double randomHeightWidth = (double)Math.floor(Math.random()*(max-min+1)+min);
        return randomHeightWidth;
    }
}