package ca.unb.cs3035.assignment3.part2;

import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class GraphModel {
    private Edge tempEdge;

    public SimpleListProperty<Edge> edgeSimpleListPropertyProperty() {
        return edgeSimpleListProperty;
    }

    private SimpleListProperty<Edge> edgeSimpleListProperty;
    private SimpleListProperty<Vertex> vertexSimpleListProperty;

    public GraphModel(){
        ArrayList<Vertex> vertexArrayList = new ArrayList<Vertex>();
        ObservableList<Vertex> vertexObservableList = (ObservableList<Vertex>) FXCollections.observableArrayList(vertexArrayList);
        vertexSimpleListProperty = new SimpleListProperty<Vertex>(vertexObservableList);

        ArrayList<Edge> edgeArrayList = new ArrayList<Edge>();
        ObservableList<Edge> edgeObservableList = (ObservableList<Edge>) FXCollections.observableArrayList(edgeArrayList);
        edgeSimpleListProperty = new SimpleListProperty<Edge>(edgeObservableList);

        tempEdge = null;
    }

    public void addVertex(Vertex vertex){
        vertexSimpleListProperty.add(vertex);
    }
    public void removeVertex(Vertex vertex){
        vertexSimpleListProperty.remove(vertex);
    }
    public SimpleListProperty<Vertex> getVertexSimpleListProperty(){
        return vertexSimpleListProperty;
    }
    public void addEdge(Edge edge){
        edgeSimpleListProperty.add(edge);
    }
    public SimpleListProperty<Edge> getEdgeSimpleListProperty(){
        return edgeSimpleListProperty;
    }
    public Edge getTempEdge(){
        return tempEdge;
    }
    public void setTempEdge(Edge prop){
        tempEdge = prop;
    }

    public void removeEdge(SimpleListProperty<Edge> getEdgeSimpleListProperty){

    }

}
