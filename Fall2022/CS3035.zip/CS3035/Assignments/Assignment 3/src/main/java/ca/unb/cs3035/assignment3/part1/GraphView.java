package ca.unb.cs3035.assignment3.part1;

import javafx.collections.ListChangeListener;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class GraphView extends Pane {
    private boolean shiftDown = false;
    public GraphView() {

        Main.graphModel.getVertexSimpleListProperty().addListener(new ListChangeListener<Vertex>() {
            @Override
            public void onChanged(Change<? extends Vertex> c) {
                drawVertex();
            }
        });
    }

    @Override
    public void layoutChildren()
    {
        drawVertex();
    }
    public void drawVertex() {
        this.getChildren().clear();
        for(Edge e : Main.graphModel.getEdgeSimpleListProperty()){
            Line edge = new Line(e.getV1().getX(), e.getV1().getY(), e.getV2().getX(), e.getV2().getY());
            edge.setFill(Color.BLACK);
            edge.setStrokeWidth(3);
            this.getChildren().add(edge);
        }
        if(Main.graphModel.getTempEdge() != null){
            Line edge = new Line(Main.graphModel.getTempEdge().getV1().getX(), Main.graphModel.getTempEdge().getV1().getY(),
                    Main.graphModel.getTempEdge().getV2().getX(), Main.graphModel.getTempEdge().getV2().getY());
            edge.setFill(Color.BLACK);
            edge.setStrokeWidth(5);
            this.getChildren().add(edge);
        }
        for (int i = 0; i< Main.graphModel.getVertexSimpleListProperty().size(); i++)
        {
            Circle inner = new Circle(Main.graphModel.getVertexSimpleListProperty().get(i).getX(),Main.graphModel.getVertexSimpleListProperty().get(i).getY(),21);
            Circle border = new Circle(Main.graphModel.getVertexSimpleListProperty().get(i).getX(),Main.graphModel.getVertexSimpleListProperty().get(i).getY(),23);
            if(Main.graphModel.getVertexSimpleListProperty().get(i).getIsSelected()  && !shiftDown) {
                inner.setFill(Color.ORANGE);
            }
            else{
                inner.setFill(Color.LIGHTBLUE);
                if(Main.graphModel.getVertexSimpleListProperty().get(i).getIsSelected() && shiftDown){
                    border= new Circle(Main.graphModel.getVertexSimpleListProperty().get(i).getX(),Main.graphModel.getVertexSimpleListProperty().get(i).getY(),25);
                }
            }
            border.setStroke(Color.BLACK);
            this.getChildren().add(border);
            this.getChildren().add(inner);
            Text number = new Text(Integer.toString(i));
            number.setTranslateX(Main.graphModel.getVertexSimpleListProperty().get(i).getX()-5);
            number.setTranslateY(Main.graphModel.getVertexSimpleListProperty().get(i).getY()+5);
            number.setFont(new Font(25));
            this.getChildren().add(number);
        }
    }

    public void setShiftDown(boolean e) {
        shiftDown = e;
    }
    public boolean isShiftDown(){
        return shiftDown;
    }
}
