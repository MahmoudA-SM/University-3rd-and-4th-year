package ca.unb.cs3035.assignment3.part2;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.paint.Color;

public class Vertex {
    private double x, y;
    private SimpleBooleanProperty isSelected;
    private Color color;

    public Vertex(double x, double y, Color color){
        this.x = x;
        this.y = y;
        isSelected = new SimpleBooleanProperty();
        isSelected.set(false);
        this.color = color;
    }

    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }

    public void setX(double xIn){
        x = xIn;
    }

    public void setY(double yIn){
        y = yIn;
    }

    public void chooseVertex(){
        this.isSelected.set(true);
    }
    public void notChooseVertex(){
        this.isSelected.set(false);
    }
    public boolean getIsSelected(){
        return isSelected.get();
    }

    public void setVertexColor(Color color){
        this.color = color;
    }

    public Color getVertexColor(){
        return color;
    }



}
