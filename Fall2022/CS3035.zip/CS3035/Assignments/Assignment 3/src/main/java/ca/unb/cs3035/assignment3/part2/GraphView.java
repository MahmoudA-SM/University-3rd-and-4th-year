package ca.unb.cs3035.assignment3.part2;

import javafx.collections.ListChangeListener;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class GraphView extends BorderPane {
    private boolean shiftPressed = false;
    public GraphView() {

        setPrefWidth(500);
        setPrefHeight(500);
        Main.graphModel.getVertexSimpleListProperty().addListener(new ListChangeListener<Vertex>() {
            @Override
            public void onChanged(Change<? extends Vertex> change) {
                drawVertex();
            }
        });
    }

    @Override
    public void layoutChildren()
    {
        drawVertex();
    }
    public void drawVertex() {
        this.getChildren().clear();


        for(Edge edge : Main.graphModel.getEdgeSimpleListProperty()){

            Line line = new Line(edge.getV1().getX(), edge.getV1().getY(), edge.getV2().getX(), edge.getV2().getY());

            line.setStrokeWidth(2);
            line.setFill(Color.BLACK);

            this.getChildren().add(line);
        }
        if(Main.graphModel.getTempEdge() != null){
            Line line = new Line(Main.graphModel.getTempEdge().getV1().getX(), Main.graphModel.getTempEdge().getV1().getY(),
                    Main.graphModel.getTempEdge().getV2().getX(), Main.graphModel.getTempEdge().getV2().getY());
            line.setFill(Color.BLACK);
            line.setStrokeWidth(2);
            this.getChildren().add(line);
        }
        for (int i = 0; i< Main.graphModel.getVertexSimpleListProperty().size(); i++)
        {
            Circle limit = new Circle(Main.graphModel.getVertexSimpleListProperty().get(i).getX(),Main.graphModel.getVertexSimpleListProperty().get(i).getY(),23);
            Circle circle = new Circle(Main.graphModel.getVertexSimpleListProperty().get(i).getX(),Main.graphModel.getVertexSimpleListProperty().get(i).getY(),21);
            if(Main.graphModel.getVertexSimpleListProperty().get(i).getIsSelected()  && !shiftPressed) {
                circle.setFill(Color.ORANGE);
            }
            else{
                circle.setFill(Main.graphModel.getVertexSimpleListProperty().get(i).getVertexColor());

                if(Main.graphModel.getVertexSimpleListProperty().get(i).getIsSelected() && shiftPressed){
                    limit= new Circle(Main.graphModel.getVertexSimpleListProperty().get(i).getX(),Main.graphModel.getVertexSimpleListProperty().get(i).getY(),25);
                }

            }
            limit.setStroke(Color.BLACK);
            this.getChildren().add(limit);
            this.getChildren().add(circle);
            Text circleLabel = new Text(Integer.toString(i));
            circleLabel.setTranslateY(Main.graphModel.getVertexSimpleListProperty().get(i).getY()+7);
            circleLabel.setTranslateX(Main.graphModel.getVertexSimpleListProperty().get(i).getX()-4);
            circleLabel.setFont(new Font(23));
            this.getChildren().add(circleLabel);
        }
    }

    public void setShiftPressed(boolean e) {
        shiftPressed = e;
    }
    public boolean isShiftPressed(){
        return shiftPressed;
    }
}
