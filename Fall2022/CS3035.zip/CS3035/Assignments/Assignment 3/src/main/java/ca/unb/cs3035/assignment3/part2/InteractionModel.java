package ca.unb.cs3035.assignment3.part2;

import javafx.scene.paint.Color;

public class InteractionModel {


    private boolean create, delete;
    private Color currentColor;


    public InteractionModel(){
        currentColor = Color.LIGHTBLUE;
    }

    public void setCreate(){
        if (!create){
            create = true;
            delete = false;
        }
        else{
            create = false;
            delete = false;
        }
    }

    public void setDelete() {
        if (!delete){
            create = false;
            delete = true;
        }
        else{
            create = false;
            delete = false;
        }
    }

    public boolean isCreate() {
        return create;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setCurrentColor(Color currentColor) {
        this.currentColor = currentColor;
    }

    public Color getCurrentColor(){
        return currentColor;
    }
}
