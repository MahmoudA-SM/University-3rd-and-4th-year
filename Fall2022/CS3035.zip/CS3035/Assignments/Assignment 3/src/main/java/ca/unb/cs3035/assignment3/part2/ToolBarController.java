package ca.unb.cs3035.assignment3.part2;

import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;

public class ToolBarController {

    enum action {
        NONE,
        CREATE,
        DELETE
    }
    public ToggleGroup actionGroup;
    public ToggleGroup colorGroup;
    private action currentAction;

    public ToolBarController() {
        currentAction = action.NONE;
    }



    public void setColorGreen() {
        if (Main.interactionModel.getCurrentColor() != Color.GREEN) {
            Main.interactionModel.setCurrentColor(Color.GREEN);
        } else {
            Main.interactionModel.setCurrentColor(Color.WHITE);
        }
    }

    public void setColorRed() {
        if (Main.interactionModel.getCurrentColor() != Color.RED) {
            Main.interactionModel.setCurrentColor(Color.RED);
        } else {
            Main.interactionModel.setCurrentColor(Color.WHITE);
        }
    }

    public void setColorBlue() {
        if (Main.interactionModel.getCurrentColor() != Color.BLUE) {
            Main.interactionModel.setCurrentColor(Color.BLUE);
        } else {
            Main.interactionModel.setCurrentColor(Color.WHITE);
        }
    }

    public void setActionCreate() {
        Main.interactionModel.setCreate();
    }

    public void setActionDelete() {
        Main.interactionModel.setDelete();

    }

    public action getCurrentAction() {
        return currentAction;
    }
}
