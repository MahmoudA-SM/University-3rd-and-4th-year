package ca.unb.cs3035.assignment3.part2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    public static final GraphModel graphModel = new GraphModel();
    public static final GraphView graphView = new GraphView();
    public static final GraphViewController graphViewController = new GraphViewController();

    public static final ToolBarController toolbarController = new ToolBarController();
    public static final InteractionModel interactionModel = new InteractionModel();

    @Override
    public void start(Stage primaryStage) throws IOException {


        ToolBar tB = FXMLLoader.load(Main.class.getResource("toolbar.fxml"));
        tB.setPrefWidth(500);
        tB.setPrefHeight(50);

        VBox vBox = new VBox(tB, graphView);
        Scene scene = new Scene(vBox);


        graphView.setOnMousePressed(mouseEvent ->{
            if(!graphViewController.handleVertex(mouseEvent.getX(), mouseEvent.getY())){
                for(Vertex v : graphModel.getVertexSimpleListProperty()){
                    if (Math.pow(23, 2) >= Math.pow((mouseEvent.getX() - v.getX()), 2) + Math.pow((mouseEvent.getY()- v.getY()), 2)) {
                        v.chooseVertex();
                    }
                }
            }
        });
        graphView.setOnMouseReleased(mouseEvent-> {
            for(Vertex v : graphModel.getVertexSimpleListProperty()){
                if (v.getIsSelected()) {
                    v.notChooseVertex();
                }
            }
            if(graphModel.getTempEdge() != null){
                graphViewController.handleEdge(mouseEvent.getX(), mouseEvent.getY());
            }
            graphView.layoutChildren();

        });
        graphView.setOnMouseDragged(mouseEvent->{
            for(Vertex v : graphModel.getVertexSimpleListProperty()) {
                if (v.getIsSelected() && !graphView.isShiftPressed()) {
                    v.setX(mouseEvent.getX());
                    v.setY(mouseEvent.getY());
                }
                else if(v.getIsSelected() && graphView.isShiftPressed()){
                    graphViewController.edgeQ(v, mouseEvent.getX(), mouseEvent.getY());
                }
                graphView.layoutChildren();
            }
        });

        scene.setOnKeyPressed(event->{
            if(event.getCode() == KeyCode.SHIFT){
                graphView.setShiftPressed(true);
            }
        });
        scene.setOnKeyReleased(event->{
            if(event.getCode() == KeyCode.SHIFT){
                graphView.setShiftPressed(false);
            }
        });

        primaryStage.setScene(scene);
        primaryStage.setTitle("Assignment 3, Part 2");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
