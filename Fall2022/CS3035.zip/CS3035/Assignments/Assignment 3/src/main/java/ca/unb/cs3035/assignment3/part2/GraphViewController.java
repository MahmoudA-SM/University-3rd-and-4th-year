package ca.unb.cs3035.assignment3.part2;

public class GraphViewController {


    private boolean shiftPressed = false;




    public boolean handleVertex(double x, double y){
        Vertex vertex = new Vertex(x,y, Main.interactionModel.getCurrentColor());
        boolean add = true;
        if(Main.graphModel.getVertexSimpleListProperty().isEmpty() && Main.interactionModel.isCreate()){
            Main.graphModel.addVertex(vertex);
        }
        else {
            int i;
            for (i = 0; i < Main.graphModel.getVertexSimpleListProperty().size(); i++) {
                if (Math.pow((x - Main.graphModel.getVertexSimpleListProperty().get(i).getX()), 2) + Math.pow((y - Main.graphModel.getVertexSimpleListProperty().get(i).getY()), 2) <= Math.pow(46, 2)) {
                    add = false;
                    break;
                }
            }
            if (add && Main.interactionModel.isCreate()) {
                Main.graphModel.addVertex(vertex);
            }
            else if(!add && Main.interactionModel.isDelete()){


                int index = 0;
                while(index<Main.graphModel.getEdgeSimpleListProperty().size()){
                    if(Math.pow((Main.graphModel.getVertexSimpleListProperty().get(i).getX() - Main.graphModel.getEdgeSimpleListProperty().get(index).getV1().getX()), 2)
                            + Math.pow((Main.graphModel.getVertexSimpleListProperty().get(i).getY() - Main.graphModel.getEdgeSimpleListProperty().get(index).getV1().getY()), 2)
                            <= Math.pow(46, 2) ||
                            Math.pow((Main.graphModel.getVertexSimpleListProperty().get(i).getX() -
                                    Main.graphModel.getEdgeSimpleListProperty().get(index).getV2().getX()), 2) +
                                    Math.pow((Main.graphModel.getVertexSimpleListProperty().get(i).getY() -
                                            Main.graphModel.getEdgeSimpleListProperty().get(index).getV2().getY()), 2)
                                    <= Math.pow(46, 2)){
                        Main.graphModel.getEdgeSimpleListProperty().remove(index);
                        index--;
                    }
                    index++;
                }

                Main.graphModel.removeVertex(Main.graphModel.getVertexSimpleListProperty().get(i));
            }
        }
        return add;
    }

    public boolean handleEdge(double x, double y){
        boolean add = false;
        Vertex vertexToConnectTo;
        Edge edge = Main.graphModel.getTempEdge();
            for (int i = 0; i < Main.graphModel.getVertexSimpleListProperty().size(); i++) {
                if (!Main.graphModel.getVertexSimpleListProperty().get(i).getIsSelected() && Math.pow((x - Main.graphModel.getVertexSimpleListProperty().get(i).getX()), 2) + Math.pow((y - Main.graphModel.getVertexSimpleListProperty().get(i).getY()), 2) < Math.pow(46, 2)) {
                    add = true;
                    vertexToConnectTo = Main.graphModel.getVertexSimpleListProperty().get(i);
                    edge.setV2(vertexToConnectTo);
                }
            }
            if (add) {

            Main.graphModel.addEdge(edge);
            Main.graphModel.setTempEdge(null);
            add = false;
            }
            else {
                Main.graphModel.setTempEdge(null);
                Main.graphView.layoutChildren();
            }

        return add;
    }

    public void edgeQ(Vertex startPoint, double x, double y){
        Vertex endPoint = new Vertex(x,y, Main.interactionModel.getCurrentColor());
        Edge newEdge = new Edge(startPoint,endPoint);
        Main.graphModel.setTempEdge(newEdge);
    }
    public void addPropEdgeToList(Edge edge){
        Main.graphModel.addEdge(edge);
    }


}
