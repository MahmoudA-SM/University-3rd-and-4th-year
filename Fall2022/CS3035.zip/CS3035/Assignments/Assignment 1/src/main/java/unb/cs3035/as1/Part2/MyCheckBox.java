package unb.cs3035.as1.Part2;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class MyCheckBox extends Pane{
    private final int WIDTH = 20, HEIGHT = 20;
    private Canvas canvas;

    private final BooleanProperty selected = new SimpleBooleanProperty();

    public MyCheckBox()
    {
        super();
        canvas = new Canvas(WIDTH, HEIGHT);
        getChildren().add(canvas);

        drawCheckBox();

        //select or deselect the widget when it is clicked
        addEventHandler(MouseEvent.MOUSE_CLICKED, new MouseHandler());
    }

    public final boolean isSelected(){
        return selected.get();
    }

    public final void setSelected(boolean selected){
        this.selected.setValue(selected);
    }

    public BooleanProperty selectedProperty(){
        return selected;
    }

    //uncomment and complete the following methods
//    public BooleanProperty selectedProperty(){}
//    public boolean isSelected(){}
//    public void setSelected(boolean selected){}

    public class MouseHandler implements EventHandler<MouseEvent>{
        @Override
        public void handle(MouseEvent click) {
            //update the selected property
            if (isSelected()){
                setSelected(false);
            }
            else {
                setSelected(true);
            }
            drawCheckBox();
        }
    }

    public void drawCheckBox()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        if(isSelected()){
        gc.setStroke(Color.DARKGREY);
        gc.strokeLine(2,2,WIDTH-2, HEIGHT-2);
        gc.strokeLine(WIDTH-2,2,2,HEIGHT-2);
        }
        if(!isSelected()){
            gc.clearRect(0,0,WIDTH,HEIGHT);
        }

        gc.setLineWidth(2);
        gc.setStroke(Color.BLACK);
        gc.strokeRect(0,0,WIDTH,HEIGHT);
    }

}
