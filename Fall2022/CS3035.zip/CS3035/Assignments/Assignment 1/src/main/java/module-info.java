module unb.cs3035.as1 {
    requires javafx.controls;
    requires javafx.fxml;

    exports unb.cs3035.as1.Part1;
    exports unb.cs3035.as1.Part2;
}