package unb.cs3035.as1.Part1;


import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Main extends Application {
    private Button quit;
    private Label a1p1;
    private RadioButton arial,times;
    private Font arialFont, timesFont;

    private ToggleGroup radioButtonGroup;

    private CheckBox bold,italic,underline;
    private FontWeight weight;

    private FontPosture posture;
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Assignment 1, Part 1");
        //Assignment 1, Part 1 Label
        a1p1 = new Label("Assignment 1, Part 1");
        a1p1.setFont(Font.font(25));
        a1p1.setAlignment(Pos.CENTER);

        //Quit Button
        quit = new Button("Quit");
        quit.setOnAction(this::QuitApp);
        //Fonts
        arialFont = Font.font("Arial",25);
        timesFont = Font.font("Times New Roman", 25);

        //RadioButtons
        radioButtonGroup = new ToggleGroup();
        arial = new RadioButton("Arial");
        arial.setOnAction(this::updateFont);
        arial.setSelected(true);
        times = new RadioButton("Times");
        times.setOnAction(this::updateFont);


        //bold,italic,underline CheckBoxes
        bold = new CheckBox("Bold");
        bold.setOnAction(this::updateFont);
        italic = new CheckBox("Italic");
        italic.setOnAction(this::updateFont);
        underline = new CheckBox("Underline");
        underline.setOnAction(this::updateFont);

        //arial-times HBox
        HBox hBox = new HBox(15,arial,times);
        hBox.setAlignment(Pos.CENTER);

        //CheckBoxes HBox
        HBox CBHbox = new HBox(15, bold,italic,underline);
        CBHbox.setAlignment(Pos.CENTER);

        //Vbox
        VBox vBox = new VBox(25, a1p1,hBox ,CBHbox, quit);
        vBox.setAlignment(Pos.CENTER);
        //Group
        StackPane pane = new StackPane(vBox);
        //Scene and PS
        Scene scene = new Scene(pane, 450,250);

        primaryStage.setScene(scene);
        primaryStage.setMinHeight(220);
        primaryStage.setMinWidth(255);
        primaryStage.show();
    }
    private void QuitApp(ActionEvent event){
        Platform.exit();
    }
    public void updateFont(ActionEvent event){


        if(arial.isSelected()){
            a1p1.setFont(arialFont);
            arial.setToggleGroup(radioButtonGroup);
        }
        if (times.isSelected()){
            a1p1.setFont(timesFont);
            times.setToggleGroup(radioButtonGroup);
        }
        if (bold.isSelected()){
            weight = FontWeight.BOLD;
        }
        else{
            weight = FontWeight.NORMAL;
        }
        if(italic.isSelected()){
            //set a1p1 to italic
            posture = FontPosture.ITALIC;
        }
        else {
            posture = FontPosture.REGULAR;
        }

        if(underline.isSelected()){
            //Underline a1p1
            a1p1.setUnderline(true);
        }
        else {
            a1p1.setUnderline(false);
        }
        a1p1.setFont(Font.font(a1p1.getFont().getName(),weight, posture, 25));

    }
    public static void main(String[] args) {
        launch(args);
    }
}


