package unb.cs3035.as1.Part2;


import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Main extends Application {
    private Label a1p2;
    private RadioButton arial,times;
    private Font arialFont, timesFont;

    private ToggleGroup radioButtonGroup;

    private FontWeight weight;

    private MyCheckBox bold, italic, underline;

    private FontPosture posture;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Assignment 1, Part 2");
        //Assignment 1, Part 1 Label
        a1p2 = new Label("Assignment 1, Part 2");
        a1p2.setFont(Font.font(25));
        a1p2.setAlignment(Pos.CENTER);

        //Quit Button
        Button quit = new Button("Quit");
        quit.setOnAction(this::QuitApp);
        //Fonts
        arialFont = Font.font("Arial",25);
        timesFont = Font.font("Times New Roman", 25);

        bold = new MyCheckBox();
        Label boldLabel = new Label("Bold");
        HBox boldHbox = new HBox(5, bold, boldLabel);

        italic = new MyCheckBox();
        Label italicLabel = new Label("Italic");
        HBox italicHbox = new HBox(5, italic, italicLabel);

        underline = new MyCheckBox();
        Label underlineLabel = new Label("Underline");
        HBox underlineHbox = new HBox(5, underline,underlineLabel);

        HBox checkboxHbox = new HBox(10, boldHbox, italicHbox, underlineHbox);
        checkboxHbox.setAlignment(Pos.CENTER);

        //RadioButtons
        radioButtonGroup = new ToggleGroup();
        arial = new RadioButton("Arial");
        arial.setOnAction(this::updateFont);
        arial.setSelected(true);
        times = new RadioButton("Times");
        times.setOnAction(this::updateFont);

        //arial-times HBox
        HBox hBox = new HBox(15,arial,times);
        hBox.setAlignment(Pos.CENTER);



        bold.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                updateFont();
            }
        });

        italic.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                updateFont();
            }
        });

        underline.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                updateFont();
            }
        });

        //Vbox
        VBox vBox = new VBox(25, a1p2,hBox ,checkboxHbox, quit);
        vBox.setAlignment(Pos.CENTER);
        //Group
        StackPane pane = new StackPane(vBox);
        //Scene and PS
        Scene scene = new Scene(pane, 450,250);

        primaryStage.setScene(scene);
        primaryStage.setMinHeight(220);
        primaryStage.setMinWidth(255);
        primaryStage.show();
    }




    private void QuitApp(ActionEvent event){
        Platform.exit();
    }

    public void updateFont(ActionEvent event){


        if(arial.isSelected()){
            a1p2.setFont(arialFont);
            arial.setToggleGroup(radioButtonGroup);
        }
        if (times.isSelected()){
            a1p2.setFont(timesFont);
            times.setToggleGroup(radioButtonGroup);
        }

        a1p2.setFont(Font.font(a1p2.getFont().getName(),weight, posture, 25));

    }
    public void updateFont() {
           if (bold.isSelected()){
            weight = FontWeight.BOLD;
        }
        else{
            weight = FontWeight.NORMAL;
        }
        if(italic.isSelected()){
            //set a1p2 to italic
            posture = FontPosture.ITALIC;
        }
        else {
            posture = FontPosture.REGULAR;
        }

        if(underline.isSelected()){
            //Underline a1p2
            a1p2.setUnderline(true);
        }
        else {
            a1p2.setUnderline(false);
        }
        a1p2.setFont(Font.font(a1p2.getFont().getName(),weight, posture, 25));
    }

        public static void main(String[] args) {
        launch(args);
    }
}


