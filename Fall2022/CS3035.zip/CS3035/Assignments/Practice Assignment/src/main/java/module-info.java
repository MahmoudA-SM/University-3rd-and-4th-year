module cs3035.practiceassignmentstarter {
    requires javafx.controls;
    requires javafx.fxml;


    opens cs3035.practiceassignment to javafx.fxml;
    exports cs3035.practiceassignment;
}