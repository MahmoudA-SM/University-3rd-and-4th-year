package cs3035.practiceassignment;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application
{
    public void start(Stage primaryStage)
    {
        Text hello = new Text(100,50,"Hello World!");
        Text question = new Text(100,80, "How are you today?");

        Group root = new Group(hello,question);
        Scene scene = new Scene(root, 300,120,Color.WHEAT);

        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
