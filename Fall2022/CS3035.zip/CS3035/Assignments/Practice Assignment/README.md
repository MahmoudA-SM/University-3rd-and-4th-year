# Practice Assignment

Update this readme with your details.

For more instructions and how to's on this practice assignment see the [description on the course website](https://cs-3035-fall-2021.github.io/en_CA/#!pages/CS3035-challenge-1.md).

In general you will need to provide your details with every submission you do on Github, and you will do it by updating the readme file. 

This challenge simply requires you to update your details, add a simple HelloWorld application, commit your changes and push it back to GitHub. For future challenges and assignments you will repeat these steps, following the instructions in the README.md file. 

## Your name

Mahmoud Moustafa

## Your Student #

3648276

## Your UNB Login

mmoustaf

## Your GitHub Account Username

mmoustafUNB3035

## Any comments, notes or considerations

Provide any ideas, feedback, problems, etc. here with your grader/instructor.
