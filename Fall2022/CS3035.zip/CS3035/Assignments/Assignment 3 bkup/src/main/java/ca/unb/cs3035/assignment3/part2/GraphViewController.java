package ca.unb.cs3035.assignment3.part2;

public class GraphViewController {

    private GraphView gV;
    private GraphModel gM;
    private boolean shiftDown = false;

    public GraphViewController(GraphModel graphModel, GraphView graphView){
        gM = graphModel;
        gV = graphView;
    }


    public boolean vertexHandler(double x, double y){
        Vertex newV = new Vertex(x,y, Main.interactionModel.getCurrentColor());
        boolean allowed = true;
        if(gM.getVertecies().isEmpty()){
            gM.addVertex(newV);
        }
        else {
            for (int i = 0; i < gM.getVertecies().size(); i++) {
                if (Math.pow((x - gM.getVertecies().get(i).getVertexX()), 2) + Math.pow((y - gM.getVertecies().get(i).getVertexY()), 2) <= Math.pow(60, 2)) {
                    allowed = false;
                }
            }
            if (allowed) {
                gM.addVertex(newV);
            }
        }
        return allowed;
    }

    public boolean edgeHandler(double x, double y){
        boolean allowed = false;
        Vertex ending = null;
        Edge edgeToAdd = gM.getPropEdge();
            for (int i = 0; i < gM.getVertecies().size(); i++) {
                if (!gM.getVertecies().get(i).getSelected() && Math.pow((x - gM.getVertecies().get(i).getVertexX()), 2) + Math.pow((y - gM.getVertecies().get(i).getVertexY()), 2) < Math.pow(30, 2)) {
                    allowed = true;
                    ending = gM.getVertecies().get(i);
                    edgeToAdd.setVertex2(ending);
                }
            }
            if(!allowed){
                gM.setPropEdge(null);
                gV.layoutChildren();
            }
            if (allowed) {

                gM.addEdge(edgeToAdd);
                gM.setPropEdge(null);
                allowed = false;
            }

        return allowed;
    }

    public void createEdgeCheck(Vertex startPoint, double x, double y){
        Vertex endPoint = new Vertex(x,y, Main.interactionModel.getCurrentColor());
        Edge newEdge = new Edge(startPoint,endPoint);
        gM.setPropEdge(newEdge);
    }
    public void addPropEdgeToList(Edge edge){
        gM.addEdge(edge);
    }


}
