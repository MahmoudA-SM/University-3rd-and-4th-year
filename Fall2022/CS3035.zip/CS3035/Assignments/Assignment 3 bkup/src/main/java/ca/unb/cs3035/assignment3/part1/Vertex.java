package ca.unb.cs3035.assignment3.part1;

import javafx.beans.property.SimpleBooleanProperty;

import java.util.ArrayList;

public class Vertex {
    private double x, y;
    private ArrayList<Edge> edgeArrayList;
    private SimpleBooleanProperty isSelected;
    public Vertex(double xIn, double yIn){
        x = xIn;
        y = yIn;
        edgeArrayList = new ArrayList<Edge>();
        isSelected = new SimpleBooleanProperty();
        isSelected.set(false);
    }
    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }

    public void setX(double xIn){
        x = xIn;
    }

    public void setY(double yIn){
        y = yIn;
    }

    public void selectVertex(){
        this.isSelected.set(true);
    }
    public void deselectVertex(){
        this.isSelected.set(false);
    }
    public boolean getIsSelected(){
        return isSelected.get();
    }
}
