package ca.unb.cs3035.assignment3.part1;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

public class Main extends Application {
    public static final GraphModel graphModel = new GraphModel();
    public static final GraphView graphView = new GraphView();
    public static final GraphViewController graphViewController = new GraphViewController();

    @Override
    public void start(Stage primaryStage) {
        Scene scene = new Scene(graphView);
        graphView.setPrefWidth(500);
        graphView.setPrefHeight(500);

        graphView.setOnMousePressed(event ->{
            if(!graphViewController.handleVertex(event.getX(), event.getY())){
                for(Vertex v : graphModel.getVertexSimpleListProperty()){
                    if (Math.pow((event.getX() - v.getX()), 2) + Math.pow((event.getY()- v.getY()), 2) <= Math.pow(30, 2)) {
                        v.selectVertex();
                    }
                }
            }
        });
        graphView.setOnMouseReleased(event-> {
            for(Vertex v : graphModel.getVertexSimpleListProperty()){
                if (v.getIsSelected()) {
                    v.deselectVertex();
                }
            }
            if(graphModel.getTempEdge() != null){
                graphViewController.handleEdge(event.getX(), event.getY());
            }
        });
        graphView.setOnMouseDragged(event->{
            for(Vertex v : graphModel.getVertexSimpleListProperty()) {
                if (v.getIsSelected() && !graphView.isShiftDown()) {
                    v.setX(event.getX());
                    v.setY(event.getY());
                }
                else if(v.getIsSelected() && graphView.isShiftDown()){
                    graphViewController.edgeCreation(v, event.getX(), event.getY());
                }
            }
        });

        scene.setOnKeyPressed(event->{
            System.out.println(event.getCode());
            if(event.getCode() == KeyCode.SHIFT){
                graphView.setShiftDown(true);
            }
        });
        scene.setOnKeyReleased(event->{
            if(event.getCode() == KeyCode.SHIFT){
                graphView.setShiftDown(false);
            }
        });

        primaryStage.setTitle("Assignment 3, Part 1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
