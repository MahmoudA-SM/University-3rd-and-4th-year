package ca.unb.cs3035.assignment3.part2;

import javafx.collections.ListChangeListener;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class GraphView extends BorderPane {
    private GraphModel gM;
    private boolean shiftDown = false;
    public GraphView(GraphModel graphModel) {
        gM = graphModel;
        gM.getVertecies().addListener(new ListChangeListener<Vertex>() {
            @Override
            public void onChanged(Change<? extends Vertex> c) {
                drawVertex();
            }
        });
    }

    @Override
    public void layoutChildren()
    {
        drawVertex();
    }
    public void drawVertex() {
        this.getChildren().clear();
        for(Edge e : gM.getEdges()){
            Line edge = new Line(e.getVertex1().getVertexX(), e.getVertex1().getVertexY(), e.getVertex2().getVertexX(), e.getVertex2().getVertexY());
            edge.setFill(Color.BLACK);
            edge.setStrokeWidth(3);
            this.getChildren().add(edge);
        }
        if(gM.getPropEdge() != null){
            Line edge = new Line(gM.getPropEdge().getVertex1().getVertexX(), gM.getPropEdge().getVertex1().getVertexY(),
                    gM.getPropEdge().getVertex2().getVertexX(), gM.getPropEdge().getVertex2().getVertexY());
            edge.setFill(Color.BLACK);
            edge.setStrokeWidth(5);
            this.getChildren().add(edge);
        }
        for (int i=0; i< gM.getVertecies().size(); i++)
        {
            Circle inner = new Circle(gM.getVertecies().get(i).getVertexX(),gM.getVertecies().get(i).getVertexY(),27);
            Circle border = new Circle(gM.getVertecies().get(i).getVertexX(),gM.getVertecies().get(i).getVertexY(),30);
            if(gM.getVertecies().get(i).getSelected()  && !shiftDown) {
                System.out.println("Selected");
                inner.setFill(Color.ORANGE);
            }
            else{
//                System.out.println(Main.toolbarController.getColorButton());
                inner.setFill(gM.getVertecies().get(i).getColor());

                if(gM.getVertecies().get(i).getSelected() && shiftDown){
                    border= new Circle(gM.getVertecies().get(i).getVertexX(),gM.getVertecies().get(i).getVertexY(),33);
                }

            }
            border.setStroke(Color.BLACK);
            this.getChildren().add(border);
            this.getChildren().add(inner);
            Text number = new Text(Integer.toString(i));
            number.setTranslateX(gM.getVertecies().get(i).getVertexX()-5);
            number.setTranslateY(gM.getVertecies().get(i).getVertexY()+5);
            number.setFont(new Font(25));
            this.getChildren().add(number);
        }
    }

    public void setShiftDown(boolean e) {
        shiftDown = e;
    }
    public boolean isShiftDown(){
        return shiftDown;
    }
}
