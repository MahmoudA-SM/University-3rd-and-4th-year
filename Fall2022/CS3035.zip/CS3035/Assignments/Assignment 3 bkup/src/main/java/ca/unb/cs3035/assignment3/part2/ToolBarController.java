package ca.unb.cs3035.assignment3.part2;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.paint.Color;

public class ToolBarController {

    enum action {
        NONE,
        CREATE,
        DELETE
    }
//    public ToggleGroup actionGroup;
//    public ToggleGroup colorGroup;

//    public ToggleButton toggleButton1 = (ToggleButton) colorGroup.getSelectedToggle();
    private action currentAction;

    public ToolBarController() {
        currentAction = action.NONE;
    }

//    public Toggle getActionButton() {
//        return actionGroup.getSelectedToggle();
//    }

//    public Toggle getColorButton(){
//        System.out.println(colorGroup.getSelectedToggle()+"7888888");
//        return colorGroup.getSelectedToggle();
//    }


    public void setColorGreen() {
        if (Main.interactionModel.getCurrentColor() != Color.GREEN) {
            Main.interactionModel.setCurrentColor(Color.GREEN);
        } else {
            Main.interactionModel.setCurrentColor(Color.WHITE);
        }
    }

    public void setColorRed() {
        if (Main.interactionModel.getCurrentColor() != Color.RED) {
            Main.interactionModel.setCurrentColor(Color.RED);
        } else {
            Main.interactionModel.setCurrentColor(Color.WHITE);
        }
    }

    public void setColorBlue() {
        if (Main.interactionModel.getCurrentColor() != Color.BLUE) {
            Main.interactionModel.setCurrentColor(Color.BLUE);
        } else {
            Main.interactionModel.setCurrentColor(Color.WHITE);
        }
    }

//    public void setColorNone() {
//        Main.interactionModel.setCurrentColor(InteractionModel.colors.WHITE);
//    }

    public void setActionCreate() {
        if (currentAction != action.CREATE) {
            currentAction = action.CREATE;
        }
    }

    public void setActionDelete() {
        if (currentAction != action.DELETE) {
            currentAction = action.DELETE;
        }
    }

//    public colors getCurrentColor() {
//        return currentColor;
//    }

    public action getCurrentAction() {
        return currentAction;
    }
}
