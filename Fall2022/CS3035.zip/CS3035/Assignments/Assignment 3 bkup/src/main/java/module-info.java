module com.example.assignment3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ca.unb.cs3035.assignment3.part2 to javafx.fxml;
    exports ca.unb.cs3035.assignment3.part1;
    exports ca.unb.cs3035.assignment3.part2;
}