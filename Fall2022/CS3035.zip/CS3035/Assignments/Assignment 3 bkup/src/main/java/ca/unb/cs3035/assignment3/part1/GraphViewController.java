package ca.unb.cs3035.assignment3.part1;

public class GraphViewController {

    private boolean isShift = false;

    public boolean handleVertex(double x, double y){
        Vertex vertex = new Vertex(x,y);
        boolean add = true;
        if(Main.graphModel.getVertexSimpleListProperty().isEmpty()){
            Main.graphModel.addVertex(vertex);
        }
        else {
            for (int i = 0; i < Main.graphModel.getVertexSimpleListProperty().size(); i++) {
                if (Math.pow((x - Main.graphModel.getVertexSimpleListProperty().get(i).getX()), 2) + Math.pow((y - Main.graphModel.getVertexSimpleListProperty().get(i).getY()), 2) <= Math.pow(60, 2)) {
                    add = false;
                }
            }
            if (add) {
                Main.graphModel.addVertex(vertex);
            }
        }
        return add;
    }

    public boolean handleEdge(double x, double y){
        boolean add = false;
        Vertex vertex;
        Edge edge = Main.graphModel.getTempEdge();
        for (int i = 0; i < Main.graphModel.getVertexSimpleListProperty().size(); i++) {
            if (!Main.graphModel.getVertexSimpleListProperty().get(i).getIsSelected() && Math.pow((x - Main.graphModel.getVertexSimpleListProperty().get(i).getX()), 2) + Math.pow((y - Main.graphModel.getVertexSimpleListProperty().get(i).getY()), 2) < Math.pow(30, 2)) {
                add = true;
                vertex = Main.graphModel.getVertexSimpleListProperty().get(i);
                edge.setV2(vertex);
            }
        }
        if(!add){
            Main.graphModel.setTempEdge(null);
            Main.graphView.layoutChildren();
        }
        if (add) {

            Main.graphModel.addEdge(edge);
            Main.graphModel.setTempEdge(null);
            add = false;
        }

        return add;
    }

    public void edgeCreation(Vertex vertex, double x, double y){
        Vertex vertex1 = new Vertex(x,y);
        Edge edge = new Edge(vertex, vertex1);
        Main.graphModel.setTempEdge(edge);
    }


}
