package ca.unb.cs3035.assignment3.part2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    public static final GraphModel graphModel = new GraphModel();
    public static final GraphView graphView = new GraphView(graphModel);
    public static final GraphViewController graphViewController = new GraphViewController(graphModel,graphView);

    public static final ToolBarController toolbarController = new ToolBarController();
    public static final InteractionModel interactionModel = new InteractionModel();

    @Override
    public void start(Stage primaryStage) throws IOException {

        graphView.setPrefWidth(500);
        graphView.setPrefHeight(500);
        ToolBar toolBar = FXMLLoader.load(Main.class.getResource("toolbar.fxml"));
        toolBar.setPrefWidth(500);
        toolBar.setPrefHeight(40);
        VBox screen = new VBox(toolBar,graphView);
        Scene scene = new Scene(screen);
        System.out.println(toolBar.getItems().get(0));

        System.out.println(toolBar.getItems());


        graphView.setOnMousePressed(event ->{
            if(!graphViewController.vertexHandler(event.getX(), event.getY())){
                for(Vertex v : graphModel.getVertecies()){
                    if (Math.pow((event.getX() - v.getVertexX()), 2) + Math.pow((event.getY()- v.getVertexY()), 2) <= Math.pow(30, 2)) {
                        v.selectVertex();
                    }
                }
            }
        });
        graphView.setOnMouseReleased(event-> {
            for(Vertex v : graphModel.getVertecies()){
                if (v.getSelected()) {
                    v.deselectVertex();
                }
            }
            if(graphModel.getPropEdge() != null){
                graphViewController.edgeHandler(event.getX(), event.getY());
            }
        });
        graphView.setOnMouseDragged(event->{
            for(Vertex v : graphModel.getVertecies()) {
                if (v.getSelected() && !graphView.isShiftDown()) {
                    v.setVertexX(event.getX());
                    v.setVertexY(event.getY());
                }
                else if(v.getSelected() && graphView.isShiftDown()){
                    graphViewController.createEdgeCheck(v, event.getX(), event.getY());
                }
                graphView.layoutChildren();
            }
        });

        scene.setOnKeyPressed(event->{
            System.out.println(event.getCode());
            if(event.getCode() == KeyCode.SHIFT){
                graphView.setShiftDown(true);
            }
        });
        scene.setOnKeyReleased(event->{
            if(event.getCode() == KeyCode.SHIFT){
                graphView.setShiftDown(false);
            }
        });

        primaryStage.setTitle("Assignment 3, Part 2");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
