package ca.unb.cs3035.assignment3.part2;

import javafx.fxml.FXMLLoader;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;

public class InteractionModel {


    private Color currentColor;


    public InteractionModel(){
        currentColor = Color.WHITE;
    }

    public void setCurrentColor(Color currentColor) {
        this.currentColor = currentColor;
    }

    public Color getCurrentColor(){
        return currentColor;
    }
}
