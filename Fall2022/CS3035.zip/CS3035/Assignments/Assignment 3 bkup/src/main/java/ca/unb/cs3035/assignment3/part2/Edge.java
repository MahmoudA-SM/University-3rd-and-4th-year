package ca.unb.cs3035.assignment3.part2;

public class Edge {
    private Vertex vertex1, vertex2;
    public Edge(Vertex v1In, Vertex v2In){
        vertex1 = v1In;
        vertex2 = v2In;
    }
    public Vertex getVertex1(){
        return vertex1;
    }
    public Vertex getVertex2(){
        return vertex2;
    }

    public void setVertex2(Vertex v){
        vertex2 = v;
    }
}
