package ca.unb.cs3035.assignment3.part1;

import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class GraphModel {

    private SimpleListProperty<Edge> edgeSimpleListProperty;

    private SimpleListProperty<Vertex> vertexSimpleListProperty;
    private Edge tempEdge;
    public GraphModel(){

        ArrayList<Vertex> vertexArrayList = new ArrayList<Vertex>();
        ObservableList<Vertex> vertexObservableList = (ObservableList<Vertex>) FXCollections.observableArrayList(vertexArrayList);
        vertexSimpleListProperty = new SimpleListProperty<Vertex>(vertexObservableList);

        ArrayList<Edge> edgeArrayList = new ArrayList<Edge>();
        ObservableList<Edge> edgeObservableList = (ObservableList<Edge>) FXCollections.observableArrayList(edgeArrayList);
        edgeSimpleListProperty = new SimpleListProperty<Edge>(edgeObservableList);

        tempEdge = null;
    }

    public void addVertex(Vertex newVertex){
        vertexSimpleListProperty.add(newVertex);
    }

    public void addEdge(Edge newEdge){
        edgeSimpleListProperty.add(newEdge);
    }
    public SimpleListProperty<Vertex> getVertexSimpleListProperty(){
        return vertexSimpleListProperty;
    }

    public SimpleListProperty<Edge> getEdgeSimpleListProperty(){
        return edgeSimpleListProperty;
    }
    public Edge getTempEdge(){
        return tempEdge;
    }
    public void setTempEdge(Edge tempEdge){
        this.tempEdge = tempEdge;
    }
}
