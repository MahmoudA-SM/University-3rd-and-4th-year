package ca.unb.cs3035.assignment3.part2;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public class Vertex {
    private double x, y;
    private ArrayList<Edge> edges = new ArrayList<Edge>();
    private SimpleBooleanProperty selected = new SimpleBooleanProperty();
    private Color color;

    public Vertex(double xIn, double yIn, Color color){
        x = xIn;
        y = yIn;
        selected.set(false);
        this.color = color;
    }

    public double getVertexX(){
        return x;
    }
    public double getVertexY(){
        return y;
    }

    public void setVertexX(double xIn){
        x = xIn;
    }

    public void setVertexY(double yIn){
        y = yIn;
    }

    public void selectVertex(){
        this.selected.set(true);
    }
    public void deselectVertex(){
        this.selected.set(false);
    }
    public boolean getSelected(){
        return selected.get();
    }

    public void setColor(Color color){
        this.color = color;
    }

    public Color getColor(){
        return color;
    }

}
