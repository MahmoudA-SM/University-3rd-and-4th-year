package ca.unb.cs3035.assignment3.part2;

import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class GraphModel {
    private SimpleListProperty<Vertex> vertecies;
    private SimpleListProperty<Edge> edges;
    private Edge propEdge = null;
    public GraphModel(){
        ArrayList<Vertex> vertexList = new ArrayList<Vertex>();
        ObservableList<Vertex> observableVertexList = (ObservableList<Vertex>) FXCollections.observableArrayList(vertexList);
        vertecies = new SimpleListProperty<Vertex>(observableVertexList);

        ArrayList<Edge> edgeList = new ArrayList<Edge>();
        ObservableList<Edge> observableEdgeList = (ObservableList<Edge>) FXCollections.observableArrayList(edgeList);
        edges = new SimpleListProperty<Edge>(observableEdgeList);
    }

    public void addVertex(Vertex newVertex){
        vertecies.add(newVertex);
    }
    public SimpleListProperty<Vertex> getVertecies(){
        return vertecies;
    }
    public void addEdge(Edge newEdge){
        edges.add(newEdge);
    }
    public SimpleListProperty<Edge> getEdges(){
        return edges;
    }
    public Edge getPropEdge(){
        return propEdge;
    }
    public void setPropEdge(Edge prop){
        propEdge = prop;
    }
}
