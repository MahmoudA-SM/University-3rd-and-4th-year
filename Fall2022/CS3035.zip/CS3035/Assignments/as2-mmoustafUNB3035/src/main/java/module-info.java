module ca.unb.cs3035.as2 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ca.unb.cs3035.as2.Part1 to javafx.fxml;
    exports ca.unb.cs3035.as2.Part1;
    opens ca.unb.cs3035.as2.Part2 to javafx.fxml;
    exports ca.unb.cs3035.as2.Part2;
    exports ca.unb.cs3035.as2.Utility;
}