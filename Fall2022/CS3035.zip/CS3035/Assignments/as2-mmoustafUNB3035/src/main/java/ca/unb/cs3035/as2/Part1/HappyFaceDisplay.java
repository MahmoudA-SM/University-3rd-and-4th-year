package ca.unb.cs3035.as2.Part1;

import javafx.scene.layout.Pane;

public class HappyFaceDisplay extends Pane {

}
