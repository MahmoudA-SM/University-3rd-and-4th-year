# CS 3035 - Midterm Coding Test - Fall 2022

***October 20th, due 9:50am***

***This test is open book and to be completed alone.***

Below are the requirement for two coding questions. Read the instructions below carefully. 
You will be given partial code for all questions.

Remember to commit and push when you are done! You have until 9:50am to commit and push.
Remember to check the GitHub website to verify that your code has been committed.

Write the complete code application for the interfaces pictured below, using JavaFX. 
Include code for creating and configuring the controls, laying out the controls in the window (as pictured), and linking the appropriate user events with the correct actions. 
You do not need to use an MVC architecture, and you do not need to necessarily get your code working 100% (see below).

## Strategy

You are advised to write the complete code logic, even if there are errors. For example, if you do not remember specific names of widgets or methods, make up a term and comment your code to explain your functionality.
If you provide complete logic, but your code does not work, then you can still receive close to full marks.

**Note**: Images below are for guidance and illustration only. Small variations in terms of appearance that can be attributed to differences in systems or specific implementation approach are considered OK.

## Part 1

Complete the program that allow pumpkins to be drawn on the screen,
by clicking on a location. 

The basic structure of the interface must be completed in the provided ```part1.fxml``` file.

Clicking on a location on the Pane in the center area of the window, 
draws a pumpkin centered around the mouse. 

A class that can be used to display pumpkins has been provided and should be used without modification.

At the top of the Window a TextField is displayed. The TextField defaults to 50, and can be edited.
The number provided in the TextField dictates the value passed to the constructor of the Pumpkin class.
Typing a size does nothing until the Pane has been clicked and a pumpkin of the provided size is created (you can assume a valid number is entered; i.e., no validation of input is needed).

The window should be initially 400 pixels by 400 pixels. 

The image below shows the initial interface, and the second shows the interface displaying pumpkins of various sizes.

<img src="images/Part1_1.png" width="300px" />
<img src="images/Part1_2.png" width="300px" />

## Part 2

Complete the CustomPane class (the Main class is already completed for you) so it fulfills the following requirements.

Your CustomPane class will simply display one or two rectangles 
depending on the dimensions of the window. Use a ```javafx.scene.shape.Rectangle``` for 
this instead of drawing on a Canvas.

As the window is resized the rectangles are updated.
If the window's width is <= 400 pixels, then just one purple rectangle is displayed.
If the window's width is > 400 pixels, then a second green rectangle is displayed.

***Hint:***: You can set a rectangle's visibility using the ```setVisible(boolean)``` method.

Rectangles have a 40 pixels around on all sides. If there are two rectangles displayed, 
then the rectangles have 40 pixels between them.

In the bottom right-hand corner of the CustomPane a Label should be displayed.
The Label should display the current width and height of the window, 
like in the pictures below (no rounding is needed).

<img src="images/Part2_1.png" width="280px" />
<img src="images/Part2_2.png" width="360px" />
