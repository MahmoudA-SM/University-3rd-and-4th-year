package ca.unb.cs.test1.part1;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * This class creates a Canvas based drawing of a pumpkin
 * to be placed in an interface. The provided size
 * will change the size of pumpkin to be displayed.
 */
public class Pumpkin extends Canvas {

    //the constructor draws a pumpkin, where the canvas
    //height and width are set to size
    public Pumpkin(double size)
    {
        this.setHeight(size);
        this.setWidth(size);
        GraphicsContext g = this.getGraphicsContext2D();

        g.setFill(Color.ORANGE);
        g.fillOval(5, 5, size - 10, size - 10);

        g.setFill(Color.BLACK);
        g.fillRect(size/2.0 - 2, 2,4, 6);
    }
}
