package ca.unb.cs.test1.part1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * Complete this class following the instructions in README.md.
 * Read the provided comments in the code for additional guidance.
 */
public class Main extends Application {
    private double size = 50;

    @Override
    public void start(Stage stage) throws Exception
    {
        BorderPane root = new FXMLLoader(Main.class.getResource("part1.fxml")).load();
        TextField textField = (TextField) root.getTop();

        textField.textProperty().addListener((observableValue, s, t1) -> {
            size = Double.parseDouble(textField.getText());
        });
        root.setOnMouseClicked(mouseEvent -> {
            Pumpkin pumpkin = new Pumpkin(size);
            pumpkin.setLayoutX(mouseEvent.getX()-size/2);
            pumpkin.setLayoutY(mouseEvent.getY()-size/2);
            System.out.println(pumpkin.getLayoutX());
            System.out.println(pumpkin.getLayoutY());
            root.getChildren().add(pumpkin);

        });





        //you should not need to change the code below
        Scene scene = new Scene(root);
        root.setPrefSize(400,400);
        stage.setScene(scene);
        stage.setTitle("Test 1 - Part 1");

        stage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
