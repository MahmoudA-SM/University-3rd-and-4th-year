package ca.unb.cs.test1.part2;

import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

/**
 * A CustomPane that simply displays one or two rectangles,
 * depending on the available display space. Complete this
 * class following the instructions in README.md.
 */
public class CustomPane extends Pane {

    Rectangle r1, r2;
    Text display;
    public CustomPane()
    {
        super();

        r1 = new Rectangle(40, 40, 320, 320);
        r1.setFill(Color.PURPLE);
        this.getChildren().add(r1);
        r2 = new Rectangle(400, 40, 700, 700);
        r2.setVisible(false);
        r2.setFill(Color.GREEN);
        this.getChildren().add(r2);

        //add a text display and position at x=20,y=20
        display = new Text();
        display.setX(20);
        display.setY(20);

        display.setText("w: 400, h: 400");

        this.getChildren().add(display);

//        drawRectangles();
    }

    @Override
    public void layoutChildren(){

        this.widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                display.setText("w: " + Double.toString(getWidth()) + ", h: " + Double.toString(getHeight()));
            }
        });
        this.heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                display.setText("w: " + Double.toString(getWidth()) + ", h: " + Double.toString(getHeight()));
            }
        });
        drawRectangles();
    }
    public void drawRectangles()
    {


        if(this.getWidth() > 400){
            r1.setWidth(getWidth()/2 - 20);
            r2.setX(r1.getWidth()+80);
            r2.setHeight(getHeight()-40*2);
            r2.setWidth(getWidth()/2- 40*2);
            r2.setVisible(true);

        }

    }

}
