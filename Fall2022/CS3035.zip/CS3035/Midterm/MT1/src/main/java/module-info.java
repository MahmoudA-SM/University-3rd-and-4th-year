module ca.unb.cs.test1 {
    requires javafx.controls;
    requires javafx.fxml;

    exports ca.unb.cs.test1.part1;
    exports ca.unb.cs.test1.part2;

    opens ca.unb.cs.test1.part1 to javafx.fxml;
}