package ca.unb.cs.test1.part2;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * Read part2 in the README.md file.
 * This class should remain unchanged.
 * Your work for this question in the CustomPane class.
 *
 */
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        BorderPane root = new BorderPane();
        root.setPrefSize(400, 400);
        root.setCenter(new CustomPane());

        Scene scene = new Scene(root);

        primaryStage.setScene(scene);
        primaryStage.show();

        primaryStage.setTitle("Test 1, Part 2");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
