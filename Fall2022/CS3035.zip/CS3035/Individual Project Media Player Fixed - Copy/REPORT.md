# CS3035 – Course Project Description

## Description of Your Project

Below, provide a short description of what your project is, how it works, and why you selected this as your project.

## Requirements

- How/What different views did you provide for some aspect of your model?
- One view that I had was the project main view is the view of the application itself with the application media player
  volume slider, progress slider, time, etc.
- Another view is one that is present when you press the help menu item which displays an image with the functionalities
  of the software including key shortcuts.
- Another view is the one present when you click the about menu item which displays the Logo of the company and my name

- What custom widget did you create in your application?
- I created a history box that will have the video name and a delete button. The history box will be added to a history
  vbox on the left.The name is the name of the video opened and the delete button will delete the history box from the 
  history vbox

- What are the different domain objects that can be created/edited in
  your application?
  The media player and the history box

- What parts of the application/project did you find particularly challenging?
  And, what would you have liked to improve?
  To be honest, this project really stretched my limits and taught me lessons that will be very useful throughout life.
  One of those lessons is perseverance. Many times I wanted to start over but a friend of mine told me if you work on
  what you have now you will get somewhere. I did not submit a program as good as I wanted it to be, nevertheless, I am
  proud of my work - no matter how simple it may be- because it really pushed me and tested my limits. Therefore, I would
  say I loved the project however, I would make it a two-person project as it was very difficult for me to come up with
  an idea of a custom widget that would be at least related to the project.

- Any  other comments on the course project? 
  Thank you very much.


https://unbcloud-my.sharepoint.com/:v:/g/personal/mmoustaf_unb_ca/EYMbOK2nz5BIgHhDkH6KduUBHFNQzV6pMJmoSTnjaIPlEA?e=j5mJfw






