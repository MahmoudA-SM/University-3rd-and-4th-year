import tkinter as tk

class HelloWorldExample():
	# initilize window
	global window
	window = tk.Tk()

	window.title("Hello World!")
	# set window width and height
	
	def hello(event):
		helloText = tk.Label(window, text = "Hello World!" , padx = 10 
			, pady = 10, fg = "purple" , bg = "lightgray" , font = 20)
		helloText.pack()

	window.configure(bg='lightgray')
	

	btn = tk.Button(window, text ="Hello")
	btn.place(x = 10, y = 10)
	
	btn.bind('<Button-1>', hello)

	window.configure(width=500, height=300)
	window.minsize(500,300)
	window.mainloop()
	

if __name__ == "__main__":
	HelloWorldExample()
