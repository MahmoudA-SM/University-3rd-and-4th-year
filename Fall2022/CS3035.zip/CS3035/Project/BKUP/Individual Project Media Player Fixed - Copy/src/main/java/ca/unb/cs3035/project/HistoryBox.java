package ca.unb.cs3035.project;

import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.io.IOException;

public class HistoryBox extends Group {
    private Label name, time;
    private Button delete;

//    private Rectangle rectangle;
//    Group root;
//    private static double y = 0;


    public HistoryBox(Label name, Label time) throws IOException {
        this.name = name;
        this.time = time;
    }


    @Override
    public Node getStyleableNode() {
        return super.getStyleableNode();
    }
}
