package ca.unb.cs3035.project;

import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.layout.HBox;

public class MediaPlayerModel {

}
