package ca.unb.cs3035.project;


import javafx.scene.layout.BorderPane;

public class MediaPlayerView extends BorderPane {

}

