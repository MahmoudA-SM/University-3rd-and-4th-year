import java.util.List;

public interface regionInterface {
    void setRadius(float new_r);
    void setRadius(double new_r);
    void setTopK(List<Integer> topK);
    void setCone(List<List<Double>> cone);
}

