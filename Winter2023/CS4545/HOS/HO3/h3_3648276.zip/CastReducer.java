import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CastReducer extends Reducer<Text, Text, Text, Text> {
    private final static int MIN_MOVIES = 10;

    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
	
		int totalMovies = 0;
		StringBuilder movies = new StringBuilder();
		for (Text value : values) {
			String movie = value.toString();
			movies.append(movie);
			movies.append(", ");
			totalMovies++;		
	    }
	
	    
		if (totalMovies > MIN_MOVIES) {

			context.write(key, new Text(totalMovies + "\t" + movies.toString()));
		}
        
    }
}

