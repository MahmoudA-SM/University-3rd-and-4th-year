DELIMITER //
CREATE PROCEDURE delSchool
(
   IN s_id     INT
   /* Parameters */
)
BEGIN
DELETE FROM schools WHERE schoolId=s_id;
IF(ROW_COUNT() = 0) THEN
      SIGNAL SQLSTATE '52711'
        SET MESSAGE_TEXT = 'Unable to Delete the school.';
    END IF;

END //
DELIMITER ;