DELIMITER //
CREATE PROCEDURE addSchool
(
   /* Parameters */
   IN s_name     varchar(50),
  IN s_province varchar(20) ,
  IN s_language char(2) ,
  IN s_level    varchar(10)
   
)
BEGIN
   /* Do the INSERT */
    IF s_province = '' THEN SET s_province = NULL; END IF;
    /*IF s_language = '' THEN SET s_language = NULL; END IF*/

    INSERT INTO schools (name, province,language,level) VALUES
   (s_name,s_province,s_language,s_level);

    IF(ROW_COUNT() = 0) THEN
      SIGNAL SQLSTATE '52711'
        SET MESSAGE_TEXT = 'Unable to create the school.';
    END IF;

    /* If the INSERT is successful, then this will return the Id for the record */
    SELECT LAST_INSERT_ID(); /* Specific to this session */

END //
DELIMITER ;
