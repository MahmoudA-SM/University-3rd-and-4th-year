DROP TABLE IF EXISTS schools;
CREATE TABLE schools (
  schoolId INT         NOT NULL AUTO_INCREMENT,
  name     varchar(50) NOT NULL,
  province varchar(20) DEFAULT NULL,
  language char(2)     DEFAULT NULL,
  level    varchar(10) DEFAULT NULL,
  PRIMARY KEY (schoolId)
);
