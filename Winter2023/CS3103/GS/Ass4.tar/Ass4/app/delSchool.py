#!/usr/bin/env python3
#
from inspect import Parameter
import pymysql.cursors
import settings
import cgitb
import cgi
import sys
import os
cgitb.enable()

# Make the connection
dbConnection = pymysql.connect(settings.DBHOST,
                                        settings.DBUSER,
                                        settings.DBPASSWD,
                                        settings.DBDATABASE,
                                        charset='utf8mb4',
                                        cursorclass= pymysql.cursors.DictCursor)


# http headers
print ('Content-type: text/html')
print ('')

qs = os.environ['QUERY_STRING']
if 'schoolID' in qs:
    pro = qs.split('=')[1]
    #print(pro)
    #pro = int(pro)
else:
    pro =''

#sql = 'CALL delSchool(' + pro +')'
sql = "delSchool"
parameter = (pro,)
# Run query and get result
id = pro
print('<!DOCTYPE html>')
print('<head>\n\t<title>Deleting School </title>\n\t<meta charset="utf-8">\n</head>')
print('<body>')
print('<br>')
print('<a href = https://cs3103.cs.unb.ca/gsingh10/a4/index.html> Go Back to form </a>')
print('<br>')
print('<br>')
print('<h1>Deleting the School with id:{}</h1>'.format(pro))
#print('<table>')
try:
        cursor = dbConnection.cursor()
        cursor.callproc(sql,parameter)
        results = cursor.fetchall()
        dbConnection.commit()
        #print('<p> {results} </p>')
        #print('<tr><th>School ID</th><th>School Name</th><th>Province</th><th>School Language</th><th>School Level</th></tr>')
        #for row in results:
        #   if row['province'] == pro :
         #       print("<tr><td>{schoolId}</td><td> {name}</td><td>{province}</td><td>{language}</td><td>{level}</td></tr>".format(**row) )
        #       print('<tr><td>'+row['name']+'</td><td>'+row['province']+'</td></tr>' )
           # elif pro == '' or pro == 'ALL':
           #     print("<tr><td>{schoolId}</td><td> {name}</td><td>{province}</td><td>{language}</td><td>{level}</td></tr>".format(**row) )
        
        #print('</table>')
except pymysql.MySQLError as e:
        print('<p>Ooops - Things messed up: </p>')
except Exception as e:
        print('<p>Something big went wrong.</p>')
        print(e)

print('</body>\n</html>')

cursor.close()
dbConnection.close()

#End
