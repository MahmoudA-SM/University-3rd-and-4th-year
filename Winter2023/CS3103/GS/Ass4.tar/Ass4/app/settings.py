DBHOST = 'localhost'
DBUSER = 'gsingh10'
DBPASSWD = 'CHEQbW04'
DBDATABASE = 'gsingh10'
