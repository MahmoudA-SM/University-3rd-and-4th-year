if (typeof process === "object") {
  require("jsdom-global")()
}
