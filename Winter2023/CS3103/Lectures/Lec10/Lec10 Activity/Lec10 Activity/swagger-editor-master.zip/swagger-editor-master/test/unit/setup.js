// Jest config globals can go here
global.XMLHttpRequest = undefined;
