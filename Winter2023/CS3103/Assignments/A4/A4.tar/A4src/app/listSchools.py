#!/usr/bin/env python3

import pymysql.cursors
import settings
import cgitb
import cgi
import sys
import os
cgitb.enable()

#Connect

dbConnection = pymysql.connect(settings.DBHOST,
                                settings.DBUSER,
                                settings.DBPASSWD,
                                settings.DBDATABASE,
                                charset='utf8mb4',
                                cursorclass= pymysql.cursors.DictCursor)

sql = "getSchoolsByProvince"
# HTTP Headers
print ('Content-type: text/html')
print('')

qs = os.environ['QUERY_STRING']
if 'province' in qs:
    pro = qs.split('=')[1]
else:
    pro = ''
args = (pro,)
#Run query and get the results

print('<!DOCTYPE html>')
print('<head>\n\t<title>School </title>\n\t<meta charset="utf-8">\n</head>')
print('<body>')
print('<a href = http://cs3103.cs.unb.ca/mmoustaf/index.html> Go Back to index </a>')
print('<h1>List of Schools:</h1>')
print('<table>')

try:
    
    cursor = dbConnection.cursor()
    if pro == "ALL":
        sql = "getSchools"
        cursor.callproc(sql)
    else:
        cursor.callproc(sql,args)
    results = cursor.fetchall()
    print('<tr><th>School ID</th><th>School Name</th><th>Province</th><th>School Language</th><th>School Level</th></tr>')
    for row in results:
        if row['province'] == pro: 
            print("<tr><td>{schoolId}</td><td> {name}</td><td>{province}</td><td>{language}</td><td>{level}</td></tr>".format(**row) )
        elif pro == '' or pro == 'ALL':
            print("<tr><td>{schoolId}</td><td> {name}</td><td>{province}</td><td>{language}</td><td>{level}</td></tr>".format(**row) )
    print('</table>')

except pymysql.MySQLError as e:    
    print('<p>Ooops - Things messed up: </p>' + str(e))
except Exception as e:
 
    print('<p>Something big went wrong.</p>')
    print(e)

print('</body>')
print('</html>')

cursor.close()
dbConnection.close()

#END

