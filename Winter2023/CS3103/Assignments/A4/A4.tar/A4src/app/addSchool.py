#!/usr/bin/env python3

import pymysql.cursors
import settings
import cgitb
import cgi
import sys
import os
cgitb.enable()

# Make the connection
dbConnection = pymysql.connect(settings.DBHOST,
                                        settings.DBUSER,
                                        settings.DBPASSWD,
                                        settings.DBDATABASE,
                                        charset='utf8mb4',
                                        cursorclass= pymysql.cursors.DictCursor)

data = cgi.FieldStorage()
name = data.getvalue('name')
province = data.getvalue('province')
level = data.getvalue('level')
language = data.getvalue('language')


# http headers

print ('Content-type: text/html')
print ('')


sql = "addSchool"
parameters = (name,province,language,level)
# Run query and get result

print('<!DOCTYPE html>')
print('<head>\n\t<title>School Added</title>\n\t<meta charset="utf-8">\n</head>')
print('<body>')
print('<br>')
print('<a href = https://cs3103.cs.unb.ca/mmoustaf/index.html> Go Back to form </a>')
print('<br>')
print('<br>')
print('<h1>The School added: </h1>')
print('<table>')
try:
        cursor = dbConnection.cursor()
        cursor.callproc(sql,parameters)
        results = cursor.fetchall()
        dbConnection.commit()
        print('<br>')
        print('<h2> The new added school has an ID:-{LAST_INSERT_ID()}</h2>'.format(**results[0]))
        print('<tr><th>School Name</th><th>Province</th><th>School Language</th><th>School Level</th></tr>')
        print("<tr><th>{}</th><th>{}</th><th>{}</th><th>{}</th></tr>".format(name,province,language,level))
        
        print('</table>')
except pymysql.MySQLError as e:
        print('<p>Ooops - Things messed up: {e}</p>')
except Exception as e:
        print('<p>Something big went wrong.</p>')
        print(e)

print('</body>\n</html>')

cursor.close()
dbConnection.close()

#End
