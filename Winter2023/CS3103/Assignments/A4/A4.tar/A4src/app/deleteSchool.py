#!/usr/bin/env python3

import pymysql.cursors
import settings
import cgitb
import cgi
import sys
import os
import inspect

dbConnection =  pymysql.connect(settings.DBHOST,
                                settings.DBUSER,
                                settings.DBPASSWD,
                                settings.DBDATABASE,
                                charset='utf8mb4',
                                cursorclass= pymysql.cursors.DictCursor)

print('Content-type: text/html')
print('')
qs = os.environ['QUERY_STRING']
if 'id' in qs:
    id = qs.split('=')[1]

else:
   id = ''

sql = 'deleteSchool'
parameter = (id,)

print('<!DOCTYPE html>')
print('<head>\n\t<title>Deleting School </title>\n\t<meta charset="utf-8">\n</head>')
print('<body>')
print('<br>')
print('<a href = https://cs3103.cs.unb.ca/mmoustaf/index.html> Go Back to form </a>')
print('<br>')
print('<br>')
print('<h1>Deleting the School with id:{}</h1>'.format(id))
try:
    cursor = dbConnection.cursor()
    cursor.callproc(sql, parameter)
    results = cursor.fetchall()
    dbConnection.commit()

except pymysql.MySQLError as e:
        print('<p>Ooops - Things messed up: </p>')
except Exception as e:
        print('<p>Something big went wrong.</p>')
        print(e)

print('</body>')
print('</html>')

cursor.close()
dbConnection.close()

#End

