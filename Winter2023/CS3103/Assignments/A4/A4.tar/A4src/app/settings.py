DBHOST = 'cs3103.cs.unb.ca'
DBUSER = 'mmoustaf'
DBPASSWD = '4MJHyMN1'
DBDATABASE = 'mmoustaf'
