DELIMITER //
DROP PROCEDURE IF EXISTS deleteSchool //

CREATE PROCEDURE deleteSchool(IN schoolIdIn int)
BEGIN
   DELETE FROM schools
      WHERE schoolId = schoolIdIn;
END//
DELIMITER ;

