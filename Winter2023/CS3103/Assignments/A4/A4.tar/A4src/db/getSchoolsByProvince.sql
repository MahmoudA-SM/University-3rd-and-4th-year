DELIMITER //
DROP PROCEDURE IF EXISTS getSchoolsByProvince //

CREATE PROCEDURE getSchoolsByProvince(IN provinceName VARCHAR(255))
BEGIN
  /* TODO: Your SQL statement here that will select schools in a particular province (or state)*/
	SELECT * from schools WHERE province =  provinceName;
END //
DELIMITER ;
