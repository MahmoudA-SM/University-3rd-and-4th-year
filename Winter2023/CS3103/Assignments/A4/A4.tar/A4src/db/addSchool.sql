DELIMITER //
CREATE PROCEDURE addSchool
(
   /* Parameters */
	IN nameIN     varchar(50),
  	IN provinceIN varchar(20),
  	IN languageIN char(2),
  	IN levelIN    varchar(10)
)
BEGIN
   /* Do the INSERT */

   INSERT INTO schools (name, province, language, level) VALUES(nameIN, provinceIN, languageIN, levelIN);
    IF(ROW_COUNT() = 0) THEN
      SIGNAL SQLSTATE '52711'
        SET MESSAGE_TEXT = 'Unable to create the school.';
    END IF;

    /* If the INSERT is successful, then this will return the Id for the record */
    SELECT LAST_INSERT_ID(); /* Specific to this session */

END //
DELIMITER ;
